package de.uni_luebeck.isp.tessla_ws

import akka.stream.scaladsl.{Flow, Framing, Keep, StreamConverters}
import akka.stream.scaladsl.{Source, Sink}
import akka.stream.scaladsl.{GraphDSL, RunnableGraph}
import akka.stream.scaladsl._
import akka.stream.{Graph, FanOutShape2, FlowShape}
import akka.{ Done, NotUsed }

package object Util {
  /** Join parallel flows by broadcasting the input to both and merging the results into one stream.
  *
  * Useful in combination with [[filter]] or [[collect]].
  */
  def splitted[In, Out, Mat](subflows: Flow[In, Out, Mat]*)
      : Flow[In, Out, NotUsed] = {
    Flow.fromGraph(GraphDSL.create() { implicit builder: GraphDSL.Builder[NotUsed] =>
      import GraphDSL.Implicits._
      val len = subflows.length
      val broadcast = builder.add(Broadcast[In](len))
      val merge = builder.add(Merge[Out](len))
      for (i <- 0 until len) {
        broadcast.out(i) ~> subflows(i) ~> merge.in(i)
      }

      FlowShape(broadcast.in, merge.out)
    })
  }

  def coupleTermination[In, Out](flow: Flow[In, Out, _]): Flow[In, Out, NotUsed] = {
    Flow.fromGraph(GraphDSL.create() {
      implicit builder: GraphDSL.Builder[NotUsed] =>
        import GraphDSL.Implicits._
        val broadcast = builder.add(Broadcast[In](2))
        val merge = builder.add(Merge[Out](2, true))
        broadcast.out(0) ~> flow ~> merge.in(0)
        broadcast.out(1).collect{
          case _ if false => ???
        } ~> merge.in(1)
        FlowShape(broadcast.in, merge.out)
    })
  }

  /** Visit a stream without changing the value. Usefull for print-debugging */
  def visit[A](f: A => Unit) = Flow[A].map{x => f(x); x}
}
