package de.uni_luebeck.isp.tessla_ws

import akka.event.Logging
import akka.http.scaladsl.server
import akka.http.scaladsl.server.directives.DebuggingDirectives
import scopt.OptionParser

case class Config(port: Int = 80,
                  httpsPort: Int = 443,
                  keystore: String = "keystore.jks",
                  password: String = "",
                  useHttps: Boolean = false,
                  interface: String = "0.0.0.0",
                  // default to no logging
                  logging: (=> server.Route) => server.Route = r => r)

object Main {
  private def parsePort(port: String) = {
    val result = try {
      Integer.parseInt(port)
    } catch {
      case ex: NumberFormatException =>
        System.err.println(port + " is not a number.")
        sys.exit(-1)
    }
    if (result <= 0 || result >= 65535) {
      System.err.println(port + " is not a valid port.")
      sys.exit(-1)
    }
    result
  }

  def main(args: Array[String]): Unit = {
    val parser = new OptionParser[Config]("TeSSLa WS") {
      head("TeSSLa Web Service")

      opt[Int]('p', "port")
        .action((value, config) => config.copy(port = value))
        .validate(value => if (value <= 0 || value >= 65535) failure(s"$value is not a valid port.") else success)
        .text("port for HTTP (default: 80)")

      opt[Int]('q',"httpsPort")
        .action((value, config) => config.copy(httpsPort = value))
        .validate(value => if (value <= 0 || value >= 65535) failure(s"$value is not a valid port.") else success)
        .text("port for HTTPs (default: 443)")

      opt[String]('k', "keystore")
        .action((value, config) => config.copy(keystore = value))
        .text("JKS keystore for HTTPS certificates (default: keystore.jks)")

      opt[String]('w', "password")
        .action((value, config) => config.copy(password = value))
        .text("password for JKS keystore (default: )")

      opt[Unit]('s', "https")
        .action((_, config) => config.copy(useHttps = true))
        .text("enable HTTPS")

      opt[String]('b', "bind")
        .action((value, config) => config.copy(interface = value))
        .text("IP address bind (default: 0.0.0.0)")

      opt[Unit]('l', "log")
        .action((_, config) => config.copy(logging =
          DebuggingDirectives.logRequestResult(("request-result", Logging.InfoLevel))))
        .text("enable logging")

      help('h', "help")
        .text("Prints this help message and exit.")

      version('v', "version")
        .text("Print the version and exit.")
    }

    val config = parser.parse(args, Config()) getOrElse sys.exit(1)
    Server.run(config)
  }
}
