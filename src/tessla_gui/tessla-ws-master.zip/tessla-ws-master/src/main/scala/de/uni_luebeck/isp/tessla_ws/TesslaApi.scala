package de.uni_luebeck.isp.tessla_ws

import org.antlr.v4.runtime.CharStreams
import de.uni_luebeck.isp.tessla.core.Errors.TesslaError
import de.uni_luebeck.isp.tessla.interpreter
import de.uni_luebeck.isp.tessla.core.{Compiler, TranslationPhase}
import de.uni_luebeck.isp.tessla.core.IncludeResolvers

import akka.http.scaladsl.model.ws.TextMessage
import akka.stream.scaladsl.Source

import spray.json.DefaultJsonProtocol._
import spray.json._

import scala.util.{Failure, Success, Try}

import Server.executionContext
import Api._

object TesslaApi {

  final case class Request(command: String,
                           specification: String,
                           input: Option[String],
                           basetime: Option[String],
                           stopon: Option[String],
                           abortat: Option[String])

  // formats for unmarshalling and marshalling
  implicit val requestFormat = jsonFormat6(Request)

  val merged = extract.map(x => Try(x.parseJson.convertTo[Request]))
  val flow = merged.flatMapConcat {
    (input: Try[Request]) =>
      val resp = input match {
        case Failure(ex: JsonParser.ParsingException) =>
          Source.single(Result(Status, ex.summary))
        case Failure(ex: DeserializationException) =>
          Source.single(Result(Status, ex.msg))
        case Failure(ex) => Source.single(Result(Status, ex.toString))
        case Success(request) =>
          TesslaApi.handleCommand(request)
          .recover{
            case ex: Exception =>
              ex.printStackTrace()
              Result(Status, ex.toString)
            }
      }

      resp ++ Source.single(Result(Finish))
  }.map(_.toJson.compactPrint)

  val handler = flow.map(TextMessage(_)).watchTermination() { (_, done) =>
    done.onComplete {
      case Success(_) =>
        println(s"Completed successfully")
      case Failure(ex) =>
        println(s"Completed with failure : $ex")
    }
  }

  def handleCommand(request: Request): Source[Result, Any] = {
    val specSource = CharStreams.fromString(request.specification, "specification")

    val abortAt = request.abortat.map(BigInt(_))
    val trace = request.input.map(interpreter.Trace.fromString(_, "input", abortAt))

    val compilerOptions = Compiler.Options(
      baseTimeString = request.basetime
    )

    Compiler.compile(specSource, compilerOptions) match {
      case TranslationPhase.Success(spec, warnings) =>
        val warn = Source.fromIterator(() => warnings.iterator).map(w => Result(Warning, w.toString))

        val result = request.command match {
          case "verify" => Source.empty
          case "core" => {
            Source.single(Result(Output, spec.toString))
          }
          case "instreams" =>
            val list = spec.in.keys.map(_.fullName).toList
            Source.single(new ListResult(InStreamsResult, list))
          case "outstreams" =>
            val list = spec.out.map{ case (ref, _) => ref.id.fullName }
            Source.single(new ListResult(OutStreamsResult, list))
          case "run" =>
            trace match {
              case Some(input) =>
                Source.fromIterator(() => interpreter.Interpreter.run(spec, input, request.stopon, rejectUndeclaredInputs = false))
                  .via(blockingIO)
                  .async
                  .map{ t => Result(Output, t.toString) }
                  .recover {
                    case ex: TesslaError =>
                      Result(Exception, ex.toString())
                  }
              case None => Source.single(Result(Status, "Trace missing"))
            }
          case other => Source.single(Result(Status, s"Unrecognized command $other"))
        }
        warn ++ result
      case TranslationPhase.Failure(errors, warnings) =>
        val warn = Source.fromIterator(() => warnings.iterator)
          .map{ w => Result(Warning, w.toString)}
        val err = Source.fromIterator(() => errors.iterator)
          .map{ e => Result(Error, e.toString) }
        warn ++ err ++ Source.single(Result(Status, s"Compilation failed with ${warnings.length} warnings and ${errors.length} errors"))
    }
  }
}
