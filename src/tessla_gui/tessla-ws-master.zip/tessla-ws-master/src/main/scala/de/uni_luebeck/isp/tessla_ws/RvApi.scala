package de.uni_luebeck.isp.tessla_ws

import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.nio.file.Files

import akka.NotUsed
import akka.http.scaladsl.model.ws.TextMessage
import akka.stream.scaladsl.{Flow, Framing, Source, StreamConverters, _}
import akka.util.ByteString
import de.uni_luebeck.isp.tessla.core.Errors.TesslaError
import de.uni_luebeck.isp.tessla.core.{Compiler, IncludeResolvers, TesslaAST, TranslationPhase}
import de.uni_luebeck.isp.tessla.interpreter
import de.uni_luebeck.isp.tessla_ws.Api._
import de.uni_luebeck.isp.tessla_ws.Server.{executionContext, materializer}
import org.antlr.v4.runtime.{CharStream, CharStreams}
import spray.json.DefaultJsonProtocol._
import spray.json._

import scala.jdk.CollectionConverters._
import scala.util.{Failure, Success, Try}
import java.util.UUID.randomUUID

object RvApi {

  final case class Request(
                            command: String,
                            specification: Option[String],
                            c: Option[String],
                            stopon: Option[String],
                            abortat: Option[String],
                            compiler: Option[String],
                            linker: Option[String],
                          )

  implicit val requestFormat = jsonFormat7(Request)

  /** Process requests. */
  val flow = Api.extract
    .map(x => Try(x.parseJson.convertTo[Request]))
    .flatMapConcat {
      (input: Try[Request]) =>
        val resp = input match {
          case Failure(ex: JsonParser.ParsingException) =>
            Source.single(Result(Status, ex.summary))
          case Failure(ex: DeserializationException) =>
            Source.single(Result(Status, ex.msg))
          case Failure(ex) => Source.single(Result(Status, ex.toString))
          case Success(request) =>
            handleCommand(request)
        }
        resp ++ Source.single(Result(Finish))
    }
    .map(_.toJson.compactPrint)

  /** A flow that terminates early on disconnect signals. */
  val terminatingFlow = Util.coupleTermination(flow)

  val handler = terminatingFlow.map(TextMessage(_)).watchTermination() { (_, done) =>
    done.onComplete {
      case Success(_) =>
        println(s"Completed successfully")
      case Failure(ex) =>
        println(s"Completed with failure : $ex")
    }
  }

  /** Convert a string prefixed with a [block] tag into a trace. */
  def mapPrefix(s: String): Result =
    s match {
      case prefixed(key, value) =>
        key match {
          case "status" => Result(Status, value)
          case "cc" => Result(CCompiler, value)
          case "instr" => Result(Instrument, value)
          case "trace" => Result(Trace, value)
          case "binary" => Result(Binary, value)
          case "tessla" =>
            val errorPrefix = """Error: (.*)""".r
            val warningPrefix = """Warning: (.*)""".r
            value match {
              case errorPrefix(v) => Result(Error, v)
              case warningPrefix(v) => Result(Warning, v)
              case v => Result(Status, v)
            }
          case _ => Result(Status, s"Error: $s")
        }
      case _ => Result(Status, s"Error: $s")
    }

  val splitLines: Flow[ByteString, String, NotUsed] =
    Framing.delimiter(ByteString("\n"), Int.MaxValue)
      .map(_.utf8String)

  def removeContainer[A](containerName: String): Flow[A, A, Unit] =
    Flow[A]
      .watchTermination() { (_, done) =>
        done.onComplete { _ =>
          println(s"Terminate container $containerName")
          Runtime.getRuntime.exec(Array("docker", "kill", "--signal", "9", containerName))
        }
      }

  /** Process a trace. Get a stream of input events and return output events.
   *
   *
   * ┌─────────────────────────────────────────────────────────────────┐
   * │       |                                          |						  │
   * │       |                                          |						  │
   * ~~~~> sink|traceStream ~~> trace ~~> Interpreter.run | outputTrace ~~~~>
   * │       |                                          |						  │
   * │       |                                          |						  │
   * └─────────────────────────────────────────────────────────────────┘
   *
   */
  def runTessla(spec: TesslaAST.Core.Specification, stopOn: Option[String], abortAt: Option[BigInt]): Flow[String, StringResult, NotUsed] = {
    // 1. Convert the input trace from akka stream to an iterator, that can be used by the TeSSLa interpreter

    // Create a sink and a java stream (traceStream), so that everything that is written into sink
    // gets returned from `traceStream`.
    val (traceStream, sink) =
    Flow[String]
      .collect { case prefixed("trace", content) => content }
      .toMat(StreamConverters.asJavaStream[String]())(Keep.right)
      .preMaterialize()

    // 2. Run the interpreter and convert the resulting iterator back to an akka stream.
    val outputTrace = Source.fromIterator(() => {
      val iter: Iterator[String] = traceStream.iterator.asScala
      val trace = interpreter.Trace.fromLineIterator(iter, "RV trace", abortAt)
      interpreter.Interpreter.run(spec, trace, stopOn, rejectUndeclaredInputs = false)
    })
      .via(blockingIO) // mark interpreter's iterator as blocking
      .async
      .map { t => Result(Output, t.toString) }
      .recover {
        case ex: TesslaError =>
          Result(Exception, ex.toString())
      }

    // 3. Combine it all into one akka flow, that transforms input events to output events.

    // Do not create a coupled flow from sink and outputTrace, because this would terminate the outputTrace
    // source before all events are generated by TeSSLa. Propagation of termination is not handled here, but
    // by merging traceResult into the errReader below.
    Flow.fromSinkAndSource(sink, outputTrace)
  }

  /** Filter and convert all the process output lines, that do not go through the tessla interpreter. */
  val directOutput: Flow[String, Result, NotUsed] = Flow[String]
    .map {
      case line@prefixed(key, value) =>
        key match {
          case "trace" => None
          case "binary" => Some(Result(Binary, value))
          case _ => Some(Result(Status, s"Error: $line"))
        }
      case line => Some(Result(Status, s"Error: $line"))
    }
    .collect {
      case Some(s) => s
    }

  /** Return a flow that performs the TeSSLa processing for the given specification. */
  def tesslaFromSource(specSource: CharStream,
                       stopOn: Option[String], abortAt: Option[BigInt]): Flow[String, Result, NotUsed] = {

    val compilerOptions = Compiler.Options(
      baseTimeString = Some("1 ns")
    )

    val specResult = Compiler.compile(specSource, compilerOptions)
    // return combines the result of the interpreter with the
    // direct output from the instrumented process.
    specResult match {
      case TranslationPhase.Success(spec, _) =>
        val interpreterFlow = runTessla(spec, stopOn, abortAt)
        Util.splitted(directOutput, interpreterFlow)
      case TranslationPhase.Failure(_, _) =>
        // Ignore errors and warnings since they are produced by the rv script, too
        directOutput
    }
  }

  def handleCommand(request: Request): Source[Result, NotUsed] = {
    val result = request.command match {
      case "trace" =>
        val (stdout, stderr) = runProgram(request)
        stdout.merge(stderr)
          .map(mapPrefix)

      case "run" =>
        val (stdout, stderr) = runProgram(request)
        val spec = request.specification match {
          case Some(s) => CharStreams.fromString(s, "specification")
          case None => return Source.single(Result(Error, "Specification missing"))
        }

        val abortAt = request.abortat.map {
          BigInt(_)
        }
        val traceResult = stdout.via(tesslaFromSource(spec, request.stopon, abortAt))

        stderr.map(mapPrefix).merge(traceResult)
    }

    result.recover {
      case ex: TesslaError =>
        Result(Exception, ex.toString())
      case ex: Exception =>
        ex.printStackTrace()
        Result(Status, ex.toString)
    }
  }

  def runProgram(command: Request): (Source[String, NotUsed], Source[String, NotUsed]) = {
    def streamConv(stream: InputStream) =
      StreamConverters.fromInputStream(() => stream)
        .mapMaterializedValue(_ => NotUsed)
        .via(splitLines)
        .async

    val (stdout, stderr, containerName) = runProgramRaw(command)

    // We attach the removeContainer flow on the stderr stream. This may appear useless, because that means, that
    // the process gets killed, when the stderr stream ends, which is exactly when the process ends, but
    // cancellation (downstream closes the source) terminates the process:
    // No one reading any more -> stop process
    val newStderr = streamConv(stderr)
      .via(removeContainer(containerName))

    (streamConv(stdout), newStderr)
  }

  def runProgramRaw(command: Request): (InputStream, InputStream, String) = {
    val tmp = createDir
    val containerName = s"tessla-ws-${randomUUID()}"
    val cFile = tmp.resolve("main.c")
    command.c.foreach(c => Files.write(cFile, c.getBytes(StandardCharsets.UTF_8)))
    val tesslaFile = tmp.resolve("spec.tessla")
    command.specification.foreach(spec => Files.write(tesslaFile, spec.getBytes(StandardCharsets.UTF_8)))
    val compilerOptions = command.compiler.map(x => Seq("--compiler-options", x)).getOrElse(Seq())
    val linkerOptions = command.linker.map(x => Seq("--linker-options", x)).getOrElse(Seq())
    val basicCmd = Array("timeout", "5m", "rv", "--temp-dir", "/tmp/bin", "--run", "spec.tessla", "main.c")
    val cmd = basicCmd ++ compilerOptions ++ linkerOptions

    // Gitlab Docker Registry
    val dockerImage = "registry.isp.uni-luebeck.de/tessla/tessla:1.2.2"

    // Malte's private Docker Registry
    // val dockerImage = "registry.mlte.de/isp/tessla-docker"

    val dockerCmd = Array("docker", "run", "--name", containerName, "--net=none", "--volume", s"$tmp:/wd", "--workdir", "/wd", "--rm", dockerImage) ++ cmd
    val proc = Runtime.getRuntime.exec(dockerCmd)
    val stdout = proc.getInputStream
    val stderr = proc.getErrorStream
    assert(stdout != null)
    assert(stderr != null)
    (stdout, stderr, containerName)
  }

  private
  val prefixed = """\[\s*([a-z]+)\s*\] (.*)""".r

  private def createDir = {
    Files.createTempDirectory("de.uni_luebeck.isp.tessla").toRealPath()
  }
}
