package de.uni_luebeck.isp.tessla_ws

import akka.http.scaladsl.model.ws.{BinaryMessage, Message, TextMessage}
import akka.stream.scaladsl.Flow
import akka.stream.ActorAttributes

import spray.json.DefaultJsonProtocol._
import spray.json._

import scala.concurrent.Future

import Server.materializer

object Api {
  sealed abstract class StringResultType
  object Error extends StringResultType {
    override def toString = "error"
  }
  object Warning extends StringResultType {
    override def toString = "warning"
  }
  object Exception extends StringResultType {
    override def toString = "exception"
  }
  object Output extends StringResultType {
    override def toString = "output"
  }
  object Status extends StringResultType {
    override def toString = "status"
  }
  object Finish extends StringResultType {
    override def toString = "finish"
  }
  object GeneratorState extends StringResultType {
    override def toString = "generatorState"
  }
  // No more cases left.
  object End extends StringResultType {
    override def toString = "end"
  }

  object CCompiler extends StringResultType {
    override def toString = "cc"
  }
  object Instrument extends StringResultType {
    override def toString = "instr"
  }
  object Trace extends StringResultType {
    override def toString = "trace"
  }
  object Binary extends StringResultType {
    override def toString = "binary"
  }

  sealed abstract class ListResultType
  object InStreamsResult extends ListResultType
  object OutStreamsResult extends ListResultType

  implicit val stringResultTypeFormatter = new JsonFormat[StringResultType] {
    def write(what: StringResultType): JsValue = JsString(what.toString)
    def read(json: JsValue) = throw new Throwable("reading result")
  }

  implicit val listResultTypeFormatter = new JsonFormat[ListResultType] {
    def write(what: ListResultType): JsValue = JsString(what match {
      case InStreamsResult => "instreams"
      case OutStreamsResult => "outstreams"
    })
    def read(json: JsValue) = throw new Throwable("reading result")
  }

  sealed abstract class Result
  case class StringResult(kind: StringResultType, value: Option[String]) extends Result
  case class ListResult(kind: ListResultType, value: List[String]) extends Result

  object Result {
    def apply(resultType: StringResultType, msg: String): StringResult = new StringResult(resultType, Some(msg))
    def apply(resultType: StringResultType): StringResult = new StringResult(resultType, None)
  }

  implicit val stringResultFormatter = jsonFormat2(StringResult)
  implicit val listResultFormatter = jsonFormat2(ListResult)

  implicit val resultFormatter = new JsonFormat[Result] {
    def write(what: Result) = what match {
      case s: StringResult => stringResultFormatter.write(s)
      case l: ListResult => listResultFormatter.write(l)
    }
    def read(json: JsValue) = throw new Throwable("reading result")
  }

  val extract = Flow[Message]
    .mapAsync(1) {
      case TextMessage.Strict(s) => Future.successful(s)
      case TextMessage.Streamed(s) => s.runFold("")(_ + _)
      case b: BinaryMessage => throw new Exception("Binary message cannot be handled")
    }

  def blockingIoAttribute[T] = ActorAttributes.dispatcher("blocking-io-dispatcher")

  def blockingIO[T] =
    Flow[T].withAttributes(blockingIoAttribute)
}
