package de.uni_luebeck.isp.tessla_ws

import java.io.FileInputStream
import java.security.{KeyStore, SecureRandom}

import akka.actor.ActorSystem
import akka.http.scaladsl.coding.Gzip
import akka.http.scaladsl.model.Uri.Path
import akka.http.scaladsl.model.Uri.Path.{Segment, Slash}
import akka.http.scaladsl.model.{StatusCodes, Uri, headers}
import akka.http.scaladsl.model.headers.CacheDirectives
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.{ConnectionContext, Http, server}
import akka.stream.ActorMaterializer
import com.typesafe.sslconfig.akka.AkkaSSLConfig
import javax.net.ssl.{KeyManagerFactory, SSLContext, TrustManagerFactory}

import scala.annotation.tailrec
import scala.concurrent.ExecutionContextExecutor

object Server {
  implicit val system: ActorSystem = ActorSystem("tessla")
  implicit val materializer: ActorMaterializer = ActorMaterializer()
  implicit val executionContext: ExecutionContextExecutor = system.dispatcher

  def run(config: Config): Unit = {

    def fromDirectory(directory: String, extension: String) = extractUnmatchedPath { path =>
      @tailrec def check(path: Path): Boolean = path match {
        case Uri.Path.Empty           => true
        case Slash(tail)      => check(tail)
        case Segment(s, tail) if s == ".." || s.contains("\\") || s.contains("/") => false
        case Segment(s, tail) => check(tail)
      }
      if(check(path) && path.startsWithSlash) {
        getFromFile(s"$directory$path$extension")
      } else {
        println(path)
        complete(StatusCodes.BadRequest)
      }
    }

    val route = get {
      path("api" / "tessla") {
        handleWebSocketMessages(TesslaApi.handler)
      } ~ path("api" / "rv") {
        handleWebSocketMessages(RvApi.handler)
      } ~
        respondWithHeaders(headers.`Cache-Control`(CacheDirectives.public, CacheDirectives.`max-age`(60 * 60 * 24))) {
          withPrecompressedMediaTypeSupport {
            pathSingleSlash {
              getFromFile("client/index.html.gz") ~ getFromFile("client/index.html")
            } ~ fromDirectory("client", ".gz") ~ fromDirectory("client", "")
          }
        }
    }

    val redirectRoute = extractHost { hostname =>
      path(Remaining) { path =>
        redirect(s"https://$hostname:${config.httpsPort}/$path", StatusCodes.MovedPermanently)
      }
    }

    if (config.useHttps) {
      val sslConfig = AkkaSSLConfig.get(system)

      val passwordChars = config.password.toCharArray

      val https = try {
        val ks = KeyStore.getInstance("PKCS12")
        val keystoreStream = new FileInputStream(config.keystore)

        ks.load(keystoreStream, passwordChars)

        val keyManagerFactory = KeyManagerFactory.getInstance("SunX509")
        keyManagerFactory.init(ks, passwordChars)

        val tmf = TrustManagerFactory.getInstance("SunX509")
        tmf.init(ks)

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(keyManagerFactory.getKeyManagers, tmf.getTrustManagers, new SecureRandom)

        ConnectionContext.https(sslContext, Some(sslConfig))
      } catch {
        case e: Exception =>
          println(e.getMessage)
          sys.exit(-2)
      }

      val sslRoute = respondWithHeaders(headers.`Strict-Transport-Security`(31536000, includeSubDomains = true)) {
        route
      }
      Http().bindAndHandle(config.logging(sslRoute), config.interface, config.httpsPort, https)
      Http().bindAndHandle(config.logging(redirectRoute), config.interface, config.port)
      println(s"Server online at http://${config.interface}:${config.port}/")
      println(s"Server online at https://${config.interface}:${config.httpsPort}/")
    } else {
      Http().bindAndHandle(config.logging(route), config.interface, config.port)
      println(s"Server online at http://${config.interface}:${config.port}/")
    }
  }
}
