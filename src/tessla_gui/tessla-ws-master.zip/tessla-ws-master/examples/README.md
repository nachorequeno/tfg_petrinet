tessla-ws examples
==================

In order to use the example shell scripts, install the dependencies with [npm](https://www.npmjs.com/):

```bash
npm install
```

You can then run the examples as follows:

```bash
./examples.js tessla.yaml
```

Please note that [YAML](http://yaml.org/) is only used as storage format for the examples. The webservice does not communicate via YAML!
