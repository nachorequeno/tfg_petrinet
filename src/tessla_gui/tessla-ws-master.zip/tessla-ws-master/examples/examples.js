#!/usr/bin/env node
var WebSocketClient = require('websocket').client;
var yaml = require('js-yaml');
var fs = require('fs');

var client = new WebSocketClient();

if (process.argv.length < 3) {
  console.error("Missing file name argument");
  process.exit();
}

var filename = process.argv[2];

if (!fs.existsSync(filename)) {
  console.error("File '" + filename + "' not found.");
  process.exit();
}

var example = yaml.safeLoad(fs.readFileSync(filename, 'utf8'));

client.on('connectFailed', function(error) {
    console.log('client#connectFailed: ' + error.toString());
});
 
client.on('connect', function(connection) {
  connection.on('error', function(error) {
    console.log("connection#error: " + error.toString());
  });
  connection.on('close', function() {
    console.log('connection#closed');
  });
  connection.on('message', function(message) {
    if (message.type === 'utf8') {
      console.log(message.utf8Data);
    }
  });

  if (connection.connected) {
    console.log("Sending command");
    connection.sendUTF(JSON.stringify(example.data));
    if (example.timeout) {
      setTimeout(function() {
        console.log("Closing connection");
        connection.close();
      }, example.timeout);
    }
    if (example.stopafter) {
      setTimeout(function () {
        console.log("Sending stop command");
        connection.sendUTF(JSON.stringify({command: "stop"}));
      }, example.stopafter);
    }
  }
});
 
client.connect(example.address);