"use strict";

export function insertIndex(data, d) {
  var low = 0;
  var high = data.length;

  while (low < high) {
    var mid = (low + high) >>> 1;
    if (data[mid].time < d.time) {
      low = mid + 1;
    } else {
      high = mid;
    }
  }
  return low;
}
