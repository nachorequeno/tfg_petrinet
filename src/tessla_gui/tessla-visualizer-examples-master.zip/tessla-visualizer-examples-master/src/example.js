"use strict";

import * as d3 from "d3";
import {visualizer} from "tessla-visualizer";
import {insertIndex} from './utils.js';
import { slift, lift, eventCount, cn, merge, time, last, filter, delay, period, variablePeriod } from "tessla.js";


function addExample(selector, options, ...streams) {
  options.update();

  const defaultOptions = {
    axis: false,
    maxZoom: 1,
    dragPrecision: 2,
    bubbleHeight: 16,
    color: function(d) {
      if (d.value === true) {
        return "green";
      } else if (d.value === false) {
        return "red";
      } else {
        return "blue";
      }
    },
    text: function(d) {
      if (d.value === true) {
        return "tt";
      } else if (d.value === false) {
        return "ff";
      } else {
        return d.value;
      }
    },
    streams,
    onDrag: function () {
      options.update();
      visu.display();
    }
  }

  options = Object.assign(defaultOptions, options);

  if (options.timeDomain === undefined) {
    const timeExtent = options.streams.reduce((accumulator, stream) => stream.data.filter((d) => d.type === "event")
      .reduce((acc, d) => [Math.min(acc[0], d.time), Math.max(acc[1], d.time)], accumulator), [Infinity, -Infinity])
    options.timeDomain = [Math.max(0,timeExtent[0]-1), timeExtent[1]+1];
  }

  var visu = visualizer(selector, options);

  d3.select(selector).on("mouseenter", function () {
    d3.select(selector).on("mouseenter", null);
    visu.showArrows();
  });
}

function coloring(stream, color) {
  stream.data.forEach(e => e.color = color);
}

function evenOddColoring(stream) {
  stream.data.forEach(e => {
    if (e.value % 2 === 0) {
      e.color = "blue";
    } else {
      e.color = "orange";
    }
  });
}

function makeStream(name, data, options) {
  const defaultOptions = {
    editable: false,
    style: "bubbles",
    progress: 999
  }
  options = Object.assign(defaultOptions, options);

  let d = [];
  if (data && data.trim() != "") {
    d = data.split(/\s/).map(evt => {
      let e = evt.trim().split(":");
      let t = +e[0];
      let v = e[1] || "";
      if (v === "tt") {
        v = true;
      } else if (v === "ff") {
        v = false;
      } else if (v.match(/[0-9]+/)) {
        v = +v;
      }
      return {type: "event", time: t, value: v};
    });
  };
  d.push({type: "progress inclusive", time: options.progress});
  return {name, style: options.style, editable: options.editable, data: d};
}

(function srvExample() {
  let temperature = makeStream("temperature", "1:6 2:2 3:1 4:5 5:9", {editable: true});
  let low = makeStream("low");
  let high = makeStream("high");
  let unsafe = makeStream("unsafe");
  function update() {
    low.data = lift(temperature.data, t => t < 3);
    high.data = lift(temperature.data, t => t > 8);
    unsafe.data = lift(low.data, high.data, (a,b) => a || b);
  }
  addExample("#srv-container", {update}, temperature, low, high, unsafe);
}());

(function asyncExample() {
  let read = makeStream("read", "5 6 7", {editable: true, style: "unit events"});
  let write = makeStream("write", "1 2 3 6", {editable: true, style: "unit events"});
  coloring(write, "orange");
  let numReads = makeStream("numReads", "", {style: "signal"});
  let numWrites = makeStream("numWrites", "", {style: "signal"});
  coloring(numWrites, "orange");
  let safe = makeStream("safe", "", {style: "signal"});
  function update() {
    numReads.data = eventCount(read.data);
    numWrites.data = eventCount(write.data);
    coloring(numWrites, "orange");
    safe.data = slift(slift(numWrites.data, numReads.data, (a,b) => a - b), cn(2), (a,b) => a <= b);
  }
  addExample("#async-container", {update}, read, write, numReads, numWrites, safe);
}());

(function timeExample() {
  let write = makeStream("write", "2 5 7 15 18", {editable: true, style: "unit events"});
  let diff = makeStream("diff");
  let error = makeStream("error");
  function update() {
    diff.data = slift(time(write.data), last(time(write.data), write.data), (a, b) => a - b);
    coloring(diff, "orange");
    error.data = filter(slift(diff.data, cn(5), (a, b) => a >= b), slift(diff.data, cn(5), (a, b) => a - b));
    coloring(error, "red");
  }
  addExample("#time-container", {update, axis: true}, write, diff, error);
}());

(function delayExample() {
  let write = makeStream("write", "2 5 7 15 18", {style: "unit events", editable: true});
  let timeout = makeStream("timeout");
  let error = makeStream("error", "", {style: "unit events"});
  function update() {
    timeout.data = cn(write.data, 5);
    coloring(timeout, "orange");
    error.data = delay(timeout.data, write.data);
    coloring(error, "red");
  }
  addExample("#delay-container", {update, axis: true, timeDomain: [1,19]}, write, timeout, error);
}());

(function periodExample() {
  let p = makeStream("p", "", {style: "unit events"});
  function update() {
    p.data = period(2, 10);
  }
  addExample("#period-container", {update, axis: true, timeDomain: [-.5,11]}, p);
}());

(function variablePeriodExample() {
  let x = makeStream("x", "2:2 10:3", {editable: true, progress: 21});
  let p = makeStream("p");
  function update() {
    p.data = variablePeriod(x.data);
  }
  addExample("#variable-period-container", {update, axis: true}, x, p);
}());

(function mergeExample() {
  let x = makeStream("x", "1:6 3:4 4:2", {editable: true});
  evenOddColoring(x);
  let y = makeStream("y", "2:5 4:7", {editable: true});
  evenOddColoring(y);
  let merged = makeStream("merge(x,y)");
  function update() {
    merged.data = merge(x.data, y.data);
    evenOddColoring(merged);
  }
  addExample("#merge-container", {update}, x, y, merged);
}());

(function sliftExample() {
  let x = makeStream("x", "1:1 3:5 4:3 5:1", {editable: true});
  coloring(x, "red");
  let y = makeStream("y", "2:2 5:4", {editable: true});
  let x1 = makeStream("x'");
  let y1 = makeStream("y'");
  let z = makeStream("x + y");
  function update() {
    x1.data = merge(x.data, last(x.data, y.data));
    coloring(x1, "red");
    y1.data = merge(y.data, last(y.data, x.data));
    z.data = slift(x.data, y.data, (a,b) => a + b);
    coloring(z, "orange");
  }
  addExample("#slift-container", {update}, x, y, x1, y1, z);
}());

(function filterExample() {
  let z = makeStream("z", "2:tt 4:ff", {editable: true});
  let x = makeStream("x", "1 3 4 5", {editable: true, style: "unit events"});
  let z1 = makeStream("z'");
  let f = makeStream("filter(z,x)", "", {style: "unit events"});
  function update() {
    z1.data = merge(z.data, last(z.data, x.data));
    f.data = filter(z.data, x.data);
  }
  addExample("#filter-container", {update}, z, x, z1, f);
}());


// MAIN EXAMPLE

var options = {
  axis: true,
  axisOffset: 30,
  signalHeight: 20,
  plotHeight: 100,
  eventHeight: 14,
  draggerRadius: 10,
  bubbleHeight: 21,
  color: "#0000ff",
  maxZoom: 40,
  labelWidth: 100,
  streams: [
    {
      name: "hans",
      style: "dots",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "gunter",
      style: "graph",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "franz",
      style: "plot",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "gunter",
      style: "slim graph",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "slim franz",
      style: "slim plot",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "fritz",
      style: "signal",
      data: [{time: 0, value: 0}, {time: .1, value: 10}, {time: 17, value: "fritz", color: "red"}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "emil",
      style: "events",
      data: [{time: 0, value: 6}, {time: .1, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "herbert",
      style: "bubbles",
      data: [{time: 0, value: 6}, {time: .1, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "hubertus",
      style: "bool",
      data: [{time: 5, value: false}, {time: 17, value: true}, {time: 21, value: false}, {time: 22, value: true}],
      editable: true
    }
  ]
};

var visu = visualizer(document.getElementsByClassName('visualizer-container')[0], options);

d3.selectAll("input[name=panbrush]").on("click", function (event) {
  if (this.value === "brush") {
    visu.enableBrush();
  } else {
    visu.disableBrush();
    visu.showArrows()
  }
});
setTimeout(visu.showArrows, 0);

function add(data, d) {
  data.splice(insertIndex(data, d), 0, d);
  visu.display();
}

setTimeout(() => {
  add(options.streams[0].data, {time: 25, value: 10});
}, 2000);

setTimeout(() => {
  add(options.streams[1].data, {time: 16, value: 4});
}, 4000);

window.addEventListener("resize",  visu.resize);