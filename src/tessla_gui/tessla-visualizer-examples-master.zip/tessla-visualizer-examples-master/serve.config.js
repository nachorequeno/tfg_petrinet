const path = require('path');

module.exports = {
  content: path.resolve(__dirname, 'dist'),
  port: 8000,
  host: '0.0.0.0'
};
