# TeSSLa Visualizer Examples

This repository contains three separate examples for the [TeSSLa Visualizer](https://gitlab.isp.uni-luebeck.de/tessla/tessla-visualizer):

* `simple` contains a simple demo how to get started.
  
  The folder contains all the required dependencies and an HTML file demonstrating their usage. Just open the index.html in your browser to see the demo.

* `everything` contains a more advanced demo using more or less every feature of the visualizer.

  This example uses npm to load the dependencies and webpack to bundle the JavaScript. Navigate into one of the three folders and run `npm install` to install the dependencies. Then run `npm start` to compile the JavaScript and start a debugging webserver. Go to http://localhost:8000 to see the results.

* `tessla-js` combines the visualizer with [tessla.js](https://gitlab.isp.uni-luebeck.de/tessla/tessla.js) (a TeSSLa interpreter written in JavaScript) to create interactive TeSSLa examples used on the official website www.tessla.io.

  It uses the same npm and webpack setup as the previous example. See above for usage.
