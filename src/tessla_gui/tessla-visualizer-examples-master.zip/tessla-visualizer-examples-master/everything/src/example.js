"use strict";

import {visualizer} from "tessla-visualizer";

var options = {
  axis: true,
  axisOffset: 30,
  signalHeight: 20,
  plotHeight: 100,
  eventHeight: 14,
  draggerRadius: 10,
  bubbleHeight: 21,
  color: "#0000ff",
  maxZoom: 40,
  labelWidth: 100,
  streams: [
    {
      name: "hans",
      style: "dots",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "gunter",
      style: "graph",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "franz",
      style: "plot",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "gunter",
      style: "slim graph",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "slim franz",
      style: "slim plot",
      data: [{time: 5, value: 6}, {time: 10, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 29.7, value: 5}, {time: 32, value: -10}, {time: 34, value: -3}],
      editable: true
    },
    {
      name: "fritz",
      style: "signal",
      data: [{time: 0, value: 0}, {time: .1, value: 10}, {time: 17, value: "fritz", color: "red"}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "emil",
      style: "events",
      data: [{time: 0, value: 6}, {time: .1, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "herbert",
      style: "bubbles",
      data: [{time: 0, value: 6}, {time: .1, value: 10}, {time: 17, value: 20}, {time: 21, value: 7}, {time: 22, value: 17}],
      editable: true
    },
    {
      name: "hubertus",
      style: "bool",
      data: [{time: 5, value: false}, {time: 17, value: true}, {time: 21, value: false}, {time: 22, value: true}],
      editable: true
    }
  ]
};

var visu = visualizer(document.getElementsByClassName('visualizer-container')[0], options);

document.getElementById('pan').addEventListener('click', function () {
  visu.disableBrush();
  visu.showArrows()
});

document.getElementById('brush').addEventListener('click', function () {
  visu.enableBrush();
});

setTimeout(visu.showArrows, 0);

function insertIndex(data, d) {
  var low = 0;
  var high = data.length;

  while (low < high) {
    var mid = (low + high) >>> 1;
    if (data[mid].time < d.time) {
      low = mid + 1;
    } else {
      high = mid;
    }
  }
  return low;
}

function add(data, d) {
  data.splice(insertIndex(data, d), 0, d);
  visu.display();
}

setTimeout(() => {
  add(options.streams[0].data, {time: 25, value: 10});
}, 2000);

setTimeout(() => {
  add(options.streams[1].data, {time: 16, value: 4});
}, 4000);

window.addEventListener("resize", visu.resize);
