export function loadExampleFile(file, callback) {
  var url = "https://gitlab.isp.uni-luebeck.de/api/v4/projects/109/repository/files/" + encodeURIComponent(file) + "?ref=master";
  $.ajax(url).done(function (data) {
    var content = atob(data.content);
    callback(content);
  });
}
