import CodeMirror from 'codemirror';
import 'codemirror/addon/mode/simple';

CodeMirror.defineSimpleMode("tessla-stream", {
  // The start state contains the rules that are intially used
  start: [
    // The regex matches the token, the token property contains the type
    {regex: /"(?:[^\\]|\\.)*?(?:"|$)/, token: "string"},
    {regex: /\d+:/, token: "meta"},
    {regex: /\(\)/, token: "keyword"},
    {regex: /=/, token: "operator"},
    {regex: /0x[a-f\d]+|[-+]?(?:\.\d+|\d+\.?\d*)(?:e[-+]?\d+)?/i, token: "number"},
    {regex: /[a-z][a-z0-9]*/i, token: "def"}
  ]
});

CodeMirror.defineMIME("text/x-tessla-stream", "tessla-stream");