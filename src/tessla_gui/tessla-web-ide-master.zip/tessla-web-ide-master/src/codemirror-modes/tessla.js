import CodeMirror from 'codemirror';
import 'codemirror/addon/mode/simple';

CodeMirror.defineSimpleMode("tessla", {
  start: [
    {regex: /"(?:[^\\]|\\.)*?(?:"|$)/, token: "string"},
    {regex: /(?:define|def|if|then|else|out|in|as|where|return)\b/, token: "keyword"},
    {regex: /@[a-zA-Z_]+\b/, token: "qualifier"},
    {regex: /true|false|nil/, token: "atom"},
    {regex: /[-+]?\d+/, token: "number"},
    {regex: /--.*/, token: "comment"},
    {regex: /#\s*assert\s+(:?some|empty|exists|all)\b/, token: "keyword"},
    {regex: /#.*/, token: "comment"},
    {regex: /:=|\+|-|\*|\/|&|\||\^|<<|>>|<|>|<=|>=|==|!=/, token: "def"},
    {regex: /[{(]|\$\{/, indent: true},
    {regex: /[})]/, dedent: true},
    {regex: /[a-zA-Z_]\w*/, token: "variable"}
  ],
  meta: {
    dontIndentStates: ["comment"],
    lineComment: "--"
  }
});

CodeMirror.defineMIME("text/x-tessla", "tessla");
