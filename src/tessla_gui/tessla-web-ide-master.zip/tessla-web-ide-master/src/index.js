import '../index.html';

import fscreen from 'fscreen';

import $ from 'jquery';
import 'jquery-ui/ui/core';
import 'jquery-ui/ui/widgets/draggable';

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import 'font-awesome/css/font-awesome.css';

import Ladda from 'ladda';
import 'ladda/dist/ladda-themeless.min.css';

import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/eclipse.css';

import CodeMirror from 'codemirror';
import 'codemirror/mode/clike/clike';
import './codemirror-modes/tessla';
import './codemirror-modes/tessla-stream';
import 'codemirror/addon/edit/matchbrackets';

import './style.css';

import {visualizer} from "tessla-visualizer";

import { WS_BASE_ADDRESS, loadExampleFile } from './config';


const ExampleGenState = {
  RESET: 'reset',
  RECEIVING: 'receiving',
  NORMAL: 'normal',
  END: 'end',
};

$(function () {
  var GUTTER_ID = "tessla-ws-markers";
  var CLOSE_CONFIRMATION_MESSAGE = "Changes that you made may not be saved. Continue?";
  var endpoint = "rv";
  var dirty = false;
  var defaultTestCase = null;

  var ws_example_gen;
  var ws;

  var exampleGen = {
    state: ExampleGenState.RESET,
    examples: [],
    index: -1,

    received: {input: [], output: [], error: []},

    reset: function () {
      this.state = ExampleGenState.RESET;
      this.examples = [];
      this.index = -1;
      this.received = {input: [], output: [], error: []};
    },

    finish: function () {
      switch (this.state) {
        case ExampleGenState.RECEIVING:
          this.state = ExampleGenState.NORMAL;
          return true;
        case ExampleGenState.END:
          return false;
        default:
          console.error('Called finish in state %s.', this.state)
      }
    },

    hasNext: function () {
      switch (this.state) {
        case ExampleGenState.RECEIVING:
          return false;
        case ExampleGenState.END:
          return (this.examples.length>=1 && this.index+1<this.examples.length)
        case ExampleGenState.RESET:
        case ExampleGenState.NORMAL:
          return true;
      }
    },

    hasPrev: function () {
      switch (this.state) {
        case ExampleGenState.RECEIVING:
        case ExampleGenState.RESET:
          return false;
        case ExampleGenState.END:
        case ExampleGenState.NORMAL:
          return (this.examples.length>=1 && this.index>=1)
      }
    },
  };

  var cEditor = CodeMirror.fromTextArea($("#c-code")[0], {
    theme: 'eclipse',
    lineNumbers: true,
    matchBrackets: true,
    mode: "text/x-csrc",
    gutters: [GUTTER_ID]
  });
  var inputEditor = CodeMirror.fromTextArea($("#input")[0], {
    theme: 'eclipse',
    lineNumbers: true,
    matchBrackets: true,
    mode: "text/x-tessla-stream",
    gutters: [GUTTER_ID]
  });
  $(inputEditor.getWrapperElement()).hide();
  var tesslaEditor = CodeMirror.fromTextArea($("#tessla-code")[0], {
    theme: 'eclipse',
    lineNumbers: true,
    matchBrackets: true,
    mode: "text/x-tessla",
    gutters: [GUTTER_ID]
  });
  var outputEditor = CodeMirror.fromTextArea($("#output")[0], {
    theme: 'eclipse',
    lineNumbers: true,
    mode: "text/x-tessla-stream"
  });
  outputEditor.autoscroll = true;
  var statusEditor = CodeMirror.fromTextArea($("#status")[0], {
    theme: 'eclipse',
    lineNumbers: true,
    mode: "text/plain",
    readOnly: true
  });
  statusEditor.autoscroll = true;

  var visu;

  $('#showInfoModal').prop('checked', !localStorage['hideInfoModal']);
  if ($('#showInfoModal').prop('checked')) {
    $('#infoModal').modal('show');
  }

  $('#show-example-gen-buttons').prop('checked', localStorage['show-example-gen-buttons'] === "show");
  if ($('#show-example-gen-buttons').prop('checked')) {
    $('#example-gen-buttons').show();
  }

  $(window).resize(function () {
    if (visu && $('#switchVisualizer').hasClass('active')) {
      visu.resize();
    }
  });

  $('#brushOutput button').click(function () {
    var button = $(this);
    if (button.hasClass('btn-primary')) {
      // disable brush
      button.removeClass('btn-primary').addClass('btn-outline-primary');
      visu.disableBrush();
      visu.showArrows();
    } else {
      // enable brush
      button.removeClass('btn-outline-primary').addClass('btn-primary');
      visu.enableBrush();
    }
  });

  function parse_traces(editor) {
    var streams = {};
    editor.eachLine(function (line) {
      var matches;
      if (matches = line.text.match(/(\d+): (.+) = (.+)/)) {
        var e = {time: +matches[1], value: matches[3]};
        if (e.value === "true") {
          e.value = true;
          e.color = "#00dd00";
        } else if (e.value === "false") {
          e.value = false;
          e.color = "#ff0000";
        } else if (e.value === "()") {
          e.value = undefined;
        } else if (!isNaN(e.value)) {
          e.value = +e.value;
        }
        var name = matches[2];
        if (!streams[name]) {
          streams[name] = [];
        }
        streams[name].push(e);
      }
    });
    var result = [];
    Object.keys(streams).forEach(function(key) {
      var values = streams[key];
      var stream = {name: key, data: values};
      result.push(stream);
    });
    return result;
  }

  function escapeRegExp (string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& meint den komplett erkannten String
  }

  function add_trace_styles(editor, streams) {
    var styles = {
      "@VisBool": "bool",
      "@VisBubbles": "bubbles",
      "@VisDots": "dots",
      "@VisEvents": "events",
      "@VisGraph": "graph",
      "@VisPlot": "plot",
      "@VisSignal": "signal",   
      "@VisSlimGraph": "slim graph",
      "@VisSlimPlot": "slim plot",
      "@VisUnitEvents": "unit events"
    };
    var annotations = Object.keys(styles).join("|");
    var text = editor.getValue();
    var positions = {};
    streams.forEach(function (stream) {
      var name = stream.name;
      var re = new RegExp("(" + annotations + ")?\\s*out\\s+(?:.+\\s+as\\s+)?" + escapeRegExp(name) + "(?:\\s|$)", "m");
      var match = re.exec(text);
      var style;
      if (match) {
        if (styles[match[1]]) {
          style = styles[match[1]];
        }
        positions[name] = match.index;
      }
      stream.style = style || "events";
    });

    // sort traces
    streams.sort(function (a, b) {
      var positionA = positions[a.name] || 0;
      var positionB = positions[b.name] || 0;
      return positionA - positionB;
    });
  }


  function clearTestCases() {
    exampleGen.reset();
    setTestgenButtonAttr();
  }

  function switchEndpoint(target) {
    endpoint = target;
    cancel();
    $(inputEditor.getWrapperElement()).hide();
    $(cEditor.getWrapperElement()).hide();
    $('#switchTessla').removeClass('active');
    $('#switchRv').removeClass('active');
    switch(endpoint) {
      case 'tessla':
        $(inputEditor.getWrapperElement()).show();
        $('#switchTessla').addClass('active');
        $("#example_gen").removeAttr("disabled");
        setTestgenButtonAttr()
        return;
      case 'rv':
        $(cEditor.getWrapperElement()).show();
        $('#switchRv').addClass('active');
        $("#example_gen").attr("disabled","disabled");
        $("#example_gen-prev").attr("disabled","disabled");
        clearTestCases()
        defaultTestCase = null;
        return;
    }
  }

  function setTestgenButtonAttr() {
    if (exampleGen.hasNext())
        $("#example_gen").removeAttr("disabled");
    else
        $("#example_gen").attr("disabled","disabled");

    if (exampleGen.hasPrev()) {
        $("#example_gen-prev").removeAttr("disabled");
    } else {
        $("#example_gen-prev").attr("disabled","disabled");
    }
  }

  $('#switchTessla').click(function (event) {
    switchEndpoint('tessla');
    event.preventDefault();
  });

  $('#switchRv').click(function (event) {
    switchEndpoint('rv');
    event.preventDefault();
  });

  $('#switchSpecification').click(function (event) {
    event.preventDefault();
  });

  $('#switchTessla, #switchRv').dblclick(function (event) {
    $('#expandInput').click();
  });

  $('#switchSpecification').dblclick(function (event) {
    $('#expandSpecification').click();
  });

  $('#switchStatus').click(function (event) {
    event.preventDefault();
  });

  $('#switchStatus').dblclick(function (event) {
    $('#expandStatus').click();
  });

  $('#switchVisualizer').click(function (event) {
    var streams = parse_traces(outputEditor);
    if (streams.length > 0) {
      add_trace_styles(tesslaEditor, streams);

      $('#switchVisualizer').addClass('active');
      $('#switchOutput').removeClass('active');
      $(outputEditor.getWrapperElement()).hide();
      $('#visualizer').show();
      $('#brushOutput').show();
      $('#autoscrollOutput').hide();
      
      if (visu) {
        visu = undefined;
        $('#visualizer svg').html('');
      }
      visu = visualizer('#visualizer svg', {streams: streams});
    } else {
      $('#switchOutput').click();
      alert("The TeSSLa Output contains no (valid) data, so the visualization would be empty.");
    }
    event.preventDefault();
  });

  $('#switchOutput').click(function (event) {
    $('#switchVisualizer').removeClass('active');
    $('#switchOutput').addClass('active');
    $(outputEditor.getWrapperElement()).show();
    $('#visualizer').hide();
    $('#brushOutput').hide();
    $('#autoscrollOutput').show();
    visu = undefined;
    $('#visualizer svg').html('');
    event.preventDefault();
  });

  $('#switchVisualizer, #switchOutput').dblclick(function (event) {
    $('#expandOutput').click();
  });

  var ladda = Ladda.create($("#run")[0]);
  var example_gen_ladda = Ladda.create($("#example_gen")[0]);
  function enable() {
    $("#run").removeAttr("disabled");
    setTestgenButtonAttr();
    ladda.stop();
    example_gen_ladda.stop();
    $('#cancel').stop().fadeOut('fast');
    cEditor.setOption("readOnly", false);
    tesslaEditor.setOption("readOnly", false);
  }

  function disableForRun() {
    $("#run").attr("disabled","disabled");
    $("#example_gen").attr("disabled","disabled");
    ladda.start();
    //example_gen_ladda.start();
    $('#cancel').stop().fadeIn('fast');
    cEditor.setOption("readOnly", "nocursor");
    tesslaEditor.setOption("readOnly", "nocursor");
  }
  function disableForTestgen() {
    $("#run").attr("disabled","disabled");
    $("#example_gen").attr("disabled","disabled");
    //ladda.start();
    example_gen_ladda.start();
    $('#cancel').stop().fadeIn('fast');
    cEditor.setOption("readOnly", "nocursor");
    tesslaEditor.setOption("readOnly", "nocursor");
  }

  var cHints = {gutters: {}, markers: []};
  var tesslaHints = {gutters: {}, markers: []};
  var inputHints = {gutters: {}, markers: []};

  function clearHints() {
    clearEditorHints(tesslaEditor, tesslaHints);
    clearEditorHints(cEditor, cHints);
    clearEditorHints(inputEditor, inputHints);
  }

  function clearEditorHints(editor, hints) {
    hints.markers.forEach(function(marker) {marker.clear();});
    hints.markers = [];
    editor.clearGutter(GUTTER_ID);
    hints.gutters = {};
    $('.tooltip').remove();
  }

  tesslaEditor.on('change', function () {
    clearEditorHints(tesslaEditor, tesslaHints);
  });

  [outputEditor, cEditor, tesslaEditor, inputEditor].forEach(function (editor) {
    editor.on('inputRead', function () {
      dirty = true;
    });
  });

  tesslaEditor.on('change', function() {
    clearTestCases();
    defaultTestCase = null;
  });

  cEditor.on('change', function () {
    clearEditorHints(cEditor, cHints);
  });

  function makeMarker(severity, multiple) {
    var marker = document.createElement("div"), inner = marker;
    marker.className = "tessla-ws-marker-" + severity;
    if (multiple) {
      inner = marker.appendChild(document.createElement("div"));
      inner.className = "tessla-ws-marker-multiple";
    }
    return marker;
  }

  function showCHint(severity, startLine, startCh, title) {
    var line = cEditor.getLine(startLine).substring(startCh);
    var match, endCh;
    if (match = line.match(/^\w+/)) {
      endCh = startCh + match[0].length;
    } else {
      endCh = startCh + 1;
    }
    showHint(cEditor, cHints, severity, startLine, startCh, startLine, endCh, title);
  }

  function showTesslaHint(severity, startLine, startCh, endLine, endCh, title) {
    showHint(tesslaEditor, tesslaHints, severity, startLine, startCh, endLine, endCh, title);
  }

  function showInputHint(severity, startLine, startCh, endLine, endCh, title) {
    showHint(inputEditor, inputHints, severity, startLine, startCh, endLine, endCh, title);
  }

  var textMarkerId = 0;

  function showHint(editor, hints, severity, startLine, startCh, endLine, endCh, title) {
    textMarkerId += 1;
    hints.markers.push(editor.markText({line: startLine, ch: startCh}, {line: endLine, ch: endCh}, {className: 'tessla-ws-mark-' + textMarkerId + ' tessla-ws-mark-' + severity}));
    $('.' + 'tessla-ws-mark-' + textMarkerId).tooltip({placement: 'bottom', title: title, container: 'body'});
    var gutter;
    if (hints.gutters[startLine]) {
      gutter = hints.gutters[startLine];
      if (gutter.severity == 'warning') {
        gutter.severity = severity;
      }
      gutter.multiple = true;
      gutter.title += "\n" + title;
    } else {
      gutter = hints.gutters[startLine] = {
        severity: severity,
        title: title
      };
    }
    var marker = makeMarker(gutter.severity, gutter.multiple);
    editor.setGutterMarker(startLine, GUTTER_ID, marker);
    $(marker).tooltip({placement: 'right', title: gutter.title, container: 'body'});
  }

  function parseTesslaError(severity, line) {
    var match, file, severity, startLine, startCh, endLine, endCh, title;
    if (match = line.match(/^([^(]+)\((\d+),(\d+) - (\d+),(\d+)\): (.+)$/)) {
      file = match[1];
      startLine = match[2];
      startCh = match[3];
      endLine = match[4];
      endCh = match[5];
      title = match[6];
      startLine = +startLine - 1;
      startCh = +startCh - 1;
      endLine = +endLine - 1;
      endCh = +endCh - 1;
      if (file === 'input') {
        showInputHint(severity, startLine, startCh, endLine, endCh, title);
      } else {
        showTesslaHint(severity, startLine, startCh, endLine, endCh, title);
      }
    }
  }

  function parseClangError(line) {
    var match, file, startLine, startCh, severity, title;
    if (match = line.match(/^([^:]+):(\d+):(\d+): (error|warning): (.*)$/)) {
      file = match[1];
      startLine = match[2];
      startCh = match[3];
      severity = match[4];
      title = match[5];
      startLine = +startLine - 1;
      startCh = +startCh - 1;
      showCHint(severity, startLine, startCh, title);
    }
  }


  function ws_onmessage(m) {
    var data = JSON.parse(m.data);

    switch (data.kind) {
      case 'finish': // end of transmission for this command
        enable();
        return;

      case 'instr': // errors and warnings generated by the instrumenter
      case 'cc': // errors and warnings generated by the C compiler and linker
        parseClangError(data.value);
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'warning': // tessla compile warning
        parseTesslaError('warning', data.value);
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'exception': // tessla runtime error / tessla runtime exception
      case 'error': // tessla compile error
        parseTesslaError('error', data.value);
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'status': // status messages of the tessla rv script or the web service
      case 'binary': // output of the running program
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'trace': // tracing output
        addLine(inputEditor, data.value);
        return;
      case 'output': // tessla output
        addLine(outputEditor, data.value);
        return;

      default:
        console.error("Strange response", data);
        return;
    } 
  }

  function show_testcase(offset) {
    var newIndex = exampleGen.index + offset;
    if (newIndex<0 || newIndex>=exampleGen.examples.length) {
        return false;
    }
    exampleGen.index = newIndex;
    var example = exampleGen.examples[exampleGen.index];
    for (var i=0; i<example.input.length; i++) {
        var value = example.input[i];
        addLine(inputEditor, value);
    }
    for (var i=0; i<example.output.length; i++) {
        var value = example.output[i];
        addLine(outputEditor, value);
    }
    setTestgenButtonAttr();
    return true;
  }

  function ws_onmessage_example_gen(m) {
    var data = JSON.parse(m.data);

    switch (data.kind) {
      case 'end':
        exampleGen.state = ExampleGenState.END;
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'finish': // end of transmission for this command
        enable();
        exampleGen.finish();
        if (exampleGen.received.error.length===0) {
            exampleGen.examples.push(exampleGen.received);
            exampleGen.index = exampleGen.examples.length-1;
        }
        setTestgenButtonAttr();
        return;

      case 'warning': // tessla compile warning
        parseTesslaError('warning', data.value);
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'exception': // tessla runtime error / tessla runtime exception
      case 'error': // tessla compile error
        parseTesslaError('error', data.value);
        addLine(statusEditor, data.value, data.kind);
        exampleGen.received.error.push(data.value);
        return;

      case 'status': // status messages of the tessla rv script or the web service
        addLine(statusEditor, data.value, data.kind);
        return;

      case 'trace': // tracing output
        addLine(inputEditor, data.value);
        exampleGen.received.input.push(data.value);
        return;
      case 'output': // tessla output
        addLine(outputEditor, data.value);
        exampleGen.received.output.push(data.value);
        return;

      default:
        console.error("Strange response", data);
        return;
    }
  }

  function addLine(editor, line, kind) {
    if (kind) {
      line = kind.padEnd(10).toUpperCase() + line;
    }
    editor.replaceRange(line + "\n", CodeMirror.Pos(editor.lastLine()));
    if (editor.autoscroll) {
      editor.scrollTo(null, 100000);
    }
  }

  function ws_onopen() {
    sendData();
  }

  function ws_ex_onopen() {
    sendDataExampleGen();
  }

  function sendDataExampleGen() {
      var tessla = tesslaEditor.getValue();
      var runOptions = { specification: tessla }
      switch (exampleGen.state) {
        case ExampleGenState.RESET:
            runOptions.command = 'runFirst';
            break;
        case ExampleGenState.NORMAL:
            runOptions.command = 'runNext';
            break;
        default:
            console.error('Requesting next example in state %s', exampleGen.state)
      }
      if ($('#basetime').val()) {
        runOptions.basetime = $('#basetime').val();
      }
      exampleGen.state = ExampleGenState.RECEIVING;
      exampleGen.received = {input: [], output: [], error: []};

      var data = JSON.stringify(runOptions);
      ws_example_gen.send(data);
  }

  function sendData() {
    var tessla = tesslaEditor.getValue();
    var data;
    if (endpoint === "rv") {
      var c = cEditor.getValue();
      var rvOptions = {command: 'run', c: c, specification: tessla};
      if ($('#linker').val()) {
        rvOptions.linker = $('#linker').val();
      }
      if ($('#compiler').val()) {
        rvOptions.compiler = $('#compiler').val();
      }
      if ($('#stopon').val()) {
        rvOptions.stopon = $('#stopon').val();
      }
      if ($('#abortat').val()) {
        rvOptions.abortat = $('#abortat').val();
      }
      data = JSON.stringify(rvOptions);
    } else /* if (endpoint === "tessla") */ {
      var input = inputEditor.getValue();
      var runOptions = {command: 'run', input: input, specification: tessla};
      if ($('#basetime').val()) {
        runOptions.basetime = $('#basetime').val();
      }
      if ($('#stopon').val()) {
        runOptions.stopon = $('#stopon').val();
      }
      if ($('#abortat').val()) {
        runOptions.abortat = $('#abortat').val();
      }
      data = JSON.stringify(runOptions);
    }
    
    ws.send(data);
  }

  function alert(x, color) {
    if (!color) {
      color = "danger";
    }
    var content = $('<div class="alert alert-' + color + '" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + x + '</div>');
    $('#main').prepend(content);
    content.alert();
  }

  function clearAlerts() {
    $('.alert').remove();
  }

  function ws_onerror() {
    ws = undefined;
    ws_example_gen = undefined;
    enable();
    alert("Unable to connect to TeSSLa webservice.");
  }

  function ws_onclose() {
    ws = undefined;
    ws_example_gen = undefined;
    enable();
  }

  $("#run").click(function (event) {
    clearHints();
    clearAlerts();
    disableForRun();
    outputEditor.setValue('');
    $('#switchOutput').click();
    statusEditor.setValue('');
    if (!ws) {
      ws = new WebSocket(WS_BASE_ADDRESS + endpoint);
      ws.onopen = ws_onopen;
      ws.onclose = ws_onclose;
      ws.onerror = ws_onerror;
      ws.onmessage = ws_onmessage;
    } else {
      sendData();
    }
    event.preventDefault();
  });


  function example_gen_prepare() {
    clearHints();
    clearAlerts();
    outputEditor.setValue('');
    $('#switchOutput').click();
    statusEditor.setValue('');
    inputEditor.setValue('');
  }

  $("#example_gen").click(function (event) {
    // Quickly clicking sends a message despite the button being disabled.
    // Ignore it.
    if (exampleGen.state===ExampleGenState.RECEIVING) {
      event.preventDefault();
      return;
    }
    example_gen_prepare()

    if (show_testcase(1)) {
      event.preventDefault();
      return;
    }
    disableForRun();
    if (!ws_example_gen) {
      clearTestCases();
      if (defaultTestCase) {
        exampleGen.examples.push(defaultTestCase);
        exampleGen.index = 0;
      }
      ws_example_gen = new WebSocket(WS_BASE_ADDRESS + 'example-gen');
      ws_example_gen.onopen = ws_ex_onopen;
      ws_example_gen.onclose = ws_onclose;
      ws_example_gen.onerror = ws_onerror;
      ws_example_gen.onmessage = ws_onmessage_example_gen;
    } else {
      sendDataExampleGen();
    }
    event.preventDefault();
  });

  $("#example_gen-prev").click(function (event) {
    example_gen_prepare()

    show_testcase(-1);

    event.preventDefault();
  });

  function cancel() {
    if (ws) {
      if (ws.readyState !== WebSocket.OPEN) {
        ws.onerror = undefined;
      }
      ws.close();
    }
    exampleGen.state = ExampleGenState.END;
  }

  $("#cancel").click(function (event) {
    cancel();
    event.preventDefault();
  });

  function loadExample(menuItem) {
    if (dirty) {
      if (!confirm(CLOSE_CONFIRMATION_MESSAGE)) {
        return;
      }
    }
    clearTestCases();
    defaultTestCase = null;

    clearHints();
    compressAllEditors();
    [outputEditor, statusEditor, cEditor, tesslaEditor, inputEditor].forEach(function (editor) {
      editor.setValue('');
    });
    dirty = false;
    resetSettings();
    ['stopon', 'abortat', 'basetime', 'compiler', 'linker'].forEach(function(option) {
      if (menuItem[option]) {
        $("#" + option).val(menuItem[option]);
      }
    });
    switchEndpoint(menuItem.endpoint);
    $('#switchOutput').click();
    if (menuItem.tessla) {
      loadExampleFile(menuItem.tessla, function success(content) {
        tesslaEditor.setValue(content);
      });
    }
    if (menuItem.c) {
      loadExampleFile(menuItem.c, function success(content) {
        cEditor.setValue(content);
      });
    }
    if (menuItem.input) {
      loadExampleFile(menuItem.input, function success(content) {
        inputEditor.setValue(content);
        defaultTestCase = {input: content.split(/\r?\n/), output: [], error: []};
        exampleGen.examples.push(defaultTestCase);
        exampleGen.index = 0;
      });
    }
  }

  var automaticExampleLoading = true;

  function loadExampleFromHash() {
    var params = new URLSearchParams(location.hash.substr(1));
    if (params.get('tessla') && (params.get('c') || params.get('input'))) {
      automaticExampleLoading = false;
      var menuitem = {
        tessla: params.get('tessla'),
        c: params.get('c'),
        input: params.get('input'),
        endpoint: params.get('c') ? "rv" : "tessla"
      };
      ['stopon', 'abortat', 'basetime', 'compiler', 'linker'].forEach(function(option) {
        var value = params.get(option);
        if (value) {
          menuitem[option] = value;
        }
      });
      loadExample(menuitem);
    }
  }

  $(window).on('hashchange', loadExampleFromHash);
  loadExampleFromHash();

  function addExample(menuItem) {
    if (['rv', 'tessla'].indexOf(menuItem.endpoint) < 0) {
      throw "Invalid endpoint '" + menuItem.endpoint + "'. Should be 'rv' or 'tessla'.";
    }
    if (menuItem.separator) {
      $('#' + menuItem.endpoint + '-examples').append('<div class="dropdown-divider"></div>');
    } else if (menuItem.title) {
      var link = $('<a class="dropdown-item" href>' + menuItem.title + '</a>');
      link.click(function (event) {
        loadExample(menuItem);
        event.preventDefault();
      });
      $('#' + menuItem.endpoint + '-examples').append(link);
    }
  }

  loadExampleFile('index.json', function success(content) {
    var data = JSON.parse(content);
    if (data.menu && data.menu.forEach) {
      data.menu.forEach(function(item) {
        item.endpoint = 'rv';
        addExample(item);
      });
    }
    if (data.tessla && data.tessla.forEach) {
      data.tessla.forEach(function(item) {
        item.endpoint = 'tessla';
        addExample(item);
      });
      if (automaticExampleLoading) {
        loadExample(data.tessla[0]);
      }
    }
  });

  $("#fullscreen").click(function () {
    if (fscreen.fullscreenElement) {
      fscreen.exitFullscreen();
    } else {
      fscreen.requestFullscreen(document.documentElement);
    }
  });

  fscreen.addEventListener('fullscreenchange', function () {
    var button = $("#fullscreen");
    var icon = button.find('i');
    if (fscreen.fullscreenElement) {
      icon.attr('class', 'fa fa-compress');
      button.removeClass('btn-outline-light').addClass('btn-light');
    } else {
      icon.attr('class', 'fa fa-expand');
      button.removeClass('btn-light').addClass('btn-outline-light');
    }
  });

  function compressAllEditors() {
    var buttons = $('.btn-expand');
    var icons = buttons.find('i');
    icons.attr('class', 'fa fa-expand');
    buttons.removeClass('btn-primary').addClass('btn-outline-primary');
    $('.row').removeClass('row-active').show();
    $('.editor-col').removeClass('col-md-12').addClass('col-md-6').show();
  }

  $('.btn-expand').click(function () {
    var button = $(this);
    var icon = button.find('i');
    var col = button.closest('div.editor-col');
    var row = col.closest('div.row');
    if (icon.hasClass('fa-expand')) {
      icon.attr('class', 'fa fa-compress');
      button.removeClass('btn-outline-primary').addClass('btn-primary');
      $('div.editor-col, div.row').hide();
      row.addClass('row-active').show();
      col.show().removeClass('col-md-6').addClass('col-md-12');
    } else {
      compressAllEditors();
    }
  });

  $('#expandOutput').click(function (event) {
    if (visu && $('#switchVisualizer').hasClass('active')) {
      visu.resize();
    }
  });

  function editorByName(name) {
    switch (name) {
      case 'c': return cEditor;
      case 'input': return inputEditor;
      case 'tessla': return tesslaEditor;
      case 'output': return outputEditor;
      case 'status': return statusEditor;
    }
  }

  $('.btn-autoscroll').click(function () {
    var button = $(this);
    var editor = editorByName(button.data('target'));
    if (button.hasClass('btn-outline-primary')) {
      button.addClass('btn-primary').removeClass('btn-outline-primary');
      editor.autoscroll = true;
      editor.scrollTo(null, 100000);
    } else {
      button.removeClass('btn-primary').addClass('btn-outline-primary');
      editor.autoscroll = false;
    }
  });

  window.addEventListener("beforeunload", function (e) {
    if (dirty) {
      var confirmationMessage = CLOSE_CONFIRMATION_MESSAGE;
      (e || window.event).returnValue = confirmationMessage;     //Gecko + IE
      return confirmationMessage;                                //Webkit, Safari, Chrome etc.
    }
  });

  $('#showInfoModal').click(function () {
    if ($('#showInfoModal').prop('checked')) {
      localStorage.removeItem('hideInfoModal');
    } else {
      localStorage['hideInfoModal'] = "hide";
    }
  });

  $('#show-example-gen-buttons').click(function () {
    if ($('#show-example-gen-buttons').prop('checked')) {
      $('#example-gen-buttons').show();
      localStorage['show-example-gen-buttons'] = "show";
    } else {
      $('#example-gen-buttons').hide();
      localStorage.removeItem('show-example-gen-buttons');
    }
  });

  function resetSettings() {
    $("#stopon").val("");
    $("#abortat").val("");
    $("#basetime").val("");
    $("#compiler").val("");
    $("#linker").val("");
  }
  resetSettings();
});
