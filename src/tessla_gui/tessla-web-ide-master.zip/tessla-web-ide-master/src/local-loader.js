export function loadExampleFile(file, callback) {
  $.ajax('rv-examples/' + file, {dataType: 'text'}).done(function (data) {
    callback(data);
  });
}
