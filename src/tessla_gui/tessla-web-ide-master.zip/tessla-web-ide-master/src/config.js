// CONFIGURATION

// LOCALHOST
export var WS_BASE_ADDRESS = 'ws://localhost:8080/api/';
export { loadExampleFile } from './local-loader';

// DEPLOYED
// export var WS_BASE_ADDRESS = (location.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + location.host + '/api/';
// export { loadExampleFile } from './gitlab-loader';
