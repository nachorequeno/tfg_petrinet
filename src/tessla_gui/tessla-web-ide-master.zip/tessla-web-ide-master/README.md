# TeSSLa Web IDE

The current version of the TeSSLa Web IDE can be found online on http://tessla.isp.uni-luebeck.de/

## Usage of the TeSSLa Web IDE

In the upper right corner of the Web IDE you can open different examples:
  * _TeSSLa Examples_ are pure TeSSLa examples without instrumentation. The input consists of a trace file and a TeSSLa specification. (These examples work purely with the TeSSLa web service without the Docker container.)
  * _RV Examples_ are examples with instrumentation. The input consists of C code and a TeSSLa specification. (These examples needed the Docker image and the TeSSLa web service.)
After loading an example you can execute it using the green play button in the upper tool bar of the IDE.

# Running the TeSSLa Web IDE local

## 1. Install Docker

The command

    docker run --volume /some/interesting/path:/wd --rm registry.isp.uni-luebeck.de/tessla/tessla-docker bash -c 'cd /wd && ls'

must work in a non-root shell. (Replace `/some/interesting/path` with an actual existing path which contains some files.) The command above only runs `ls`, hence it should list the files inside the given folder. The command (and the path) are only meant as a verification that your docker is up and running. The web service will use a temporary directory inside the container to store files.

On Linux the current user must be a member of the `docker` group. Otherwise you cannot run the command above without `sudo`. (See [Post-installation steps for Linux](https://docs.docker.com/engine/installation/linux/linux-postinstall/) in the Docker manual.)

On Windows you have to enable _Shared Drives_ manually. Otherwise the volume mounting via `--volume` won't work. See [Shared Drives](https://gitlab.isp.uni-luebeck.de/tessla/tessla-docker#shared-drives) in the README of the TeSSLa Docker container.

The first time you use the image `registry.isp.uni-luebeck.de/tessla/tessla-docker` it will be downloaded automatically from our Docker registry. You can update the image later using

    docker pull registry.isp.uni-luebeck.de/tessla/tessla-docker

## 2. Running the TeSSLa Web Service

Download [`tessla-ws.jar`](https://gitlab.isp.uni-luebeck.de/tessla/tessla-ws/-/jobs/artifacts/master/raw/target/scala-2.13/tessla-ws.jar?job=deploy) and run it:

    java -jar tessla-ws.jar

## 3. Running TeSSLa Web IDE

Download [`tessla-web-ide.zip`](https://gitlab.isp.uni-luebeck.de/tessla/tessla-web-ide/-/jobs/artifacts/master/download?job=deploy) and extract the archive. The files inside the `dist` folder must be served through a web server. On Linux you could use for example:

    python -m SimpleHTTPServer 8000

The TeSSLa Web IDE is now available on http://localhost:8000
