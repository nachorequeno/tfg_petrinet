import * as d3 from "d3";
import { Main, TesslaEvent, TesslaStream } from "./interfaces";

import { circlesAndArrows, crisp } from "./tools";

export function displayEvents(d: TesslaStream, i: number, offset: number,
                              element: d3.Selection<SVGElement, TesslaStream, null, undefined>, main: Main) {
  const data = d.data;
  let h = main.options.eventHeight * 2;
  if (d.style === "unit events") {
    h = main.options.eventHeight;
  }
  const y = offset + h;
  const dx = main.options.eventHeight / 2;

  let xaxis = element.selectAll("path.xaxis").data([null]);
  xaxis = xaxis
    .enter().append("path").attr("class", "xaxis").call(crisp)
    .attr("stroke", "black").merge(xaxis);
  xaxis.attr("d", `M ${main.xScale(0)} ${y + h / 4} l 0 ${-h / 2} m 0 ${h / 4} L ${main.width} ${y}`);

  let label = main.container.selectAll(`text#${main.prefix}label-${i}`).data([null]);
  label = label.enter().append("text").attr("id", `${main.prefix}label-${i}`)
    .attr("text-anchor", "end")
    .attr("font-size", main.options.fontSize)
    .attr("dominant-baseline", "central")
    .merge(label);
  label.attr("x", main.labelWidth - main.options.labelDistance)
    .attr("y", y).text(d.name);

  function updatePath(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    function path(dd: TesslaEvent) {
      const x = main.xScale(dd.time);
      return `M ${x - dx} ${y - dx} L ${x + dx} ${y + dx} M ${x - dx} ${y + dx} L ${x + dx} ${y - dx}`;
    }
    elem.attr("d", (dd) => path(dd)).attr("stroke", main.strokeColor);
  }

  const events = element.selectAll("path.event").data(data).call(updatePath);
  events.enter().append("path").attr("class", "event").attr("fill", "none")
    .attr("stroke-width", 2).call(updatePath);
  events.exit().remove();

  function updateTexts(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    elem.attr("x", (dd) => main.xScale(dd.time))
      .text(main.textLabel)
      .attr("fill", main.textColor);
  }

  if (d.style !== "unit events") {
    const texts = element.selectAll("text.signal").data(data).call(updateTexts);
    texts.enter().append("text").attr("class", "signal").attr("text-anchor", "middle")
      .attr("font-size", main.options.fontSize)
      .attr("y", y - dx - 5)
      .call(updateTexts);
    texts.exit().remove();
  }

  function updateTextVisibility() {
    // texts must be ALL text.signal nodes (not only the nexly added ones)
    // otherwise the data index i cannot be used as index on nodes()!
    const texts = element.selectAll("text.signal");
    const boxes = (texts.nodes() as SVGGraphicsElement[]).map((e) => e.getBBox());
    texts.attr("opacity", (dd, ii) => {
      const me = boxes[ii];
      const prev = boxes[ii - 1] || {x: main.labelWidth, width: 0};
      const next = boxes[ii + 1] || {x: main.width, width: 0};
      return (me.x > prev.x + prev.width && me.x + me.width < next.x) ? 1 : 0;
    });
  }
  updateTextVisibility();

  circlesAndArrows(main, element, d, () => y);
}
