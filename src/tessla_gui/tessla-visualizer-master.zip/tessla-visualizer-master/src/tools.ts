import * as d3 from "d3";
import { Main, TesslaEvent, TesslaStream } from "./interfaces";

export function addDefault(options: {[x: string]: any}, defaultOptions: {[x: string]: any}) {
  options = options || {};
  for (const opt in defaultOptions) {
      if (defaultOptions.hasOwnProperty(opt) && !options.hasOwnProperty(opt)) {
          options[opt] = defaultOptions[opt];
      }
  }
  return options;
}

export function crisp(e: d3.Selection<d3.BaseType, any, d3.BaseType, any>) {
  e.attr("shape-rendering", "crispEdges");
}

function limitAndRound(v: number, domain: [number, number], precision: number) {
  const min = domain[0];
  const max = domain[1];
  const value = Math.max(min, Math.min(max, v));
  return Math.round(value * precision) / precision;
}

function repositionEvent(data: TesslaEvent[], d: TesslaEvent, i: number) {
  while (i > 0 && d.time < data[i - 1].time) {
    data[i] = data[i - 1];
    data[i - 1] = d;
    i = i - 1;
  }
  while (i < data.length - 1 && d.time > data[i + 1].time) {
    data[i] = data[i + 1];
    data[i + 1] = d;
    i = i + 1;
  }
  return i;
}

export function updateTooltip(div: d3.Selection<d3.BaseType, {}, HTMLElement, any>, d: TesslaEvent,
                              x: number, y: number) {
  if (d.value === undefined || d.value === null) {
    div.text(d.time);
  } else {
    div.text(`${d.time}: ${d.value}`);
  }
  div.style("top", (y - (div.node() as HTMLElement).getBoundingClientRect().height - 3) + "px");
  if (x > window.innerWidth / 2) {
    div
      .style("left", null)
      .style("right", (window.innerWidth - x + 3) + "px");
  } else {
    div
      .style("left", (x + 3) + "px")
      .style("right", null);
  }
}

export function circlesAndArrows(main: Main,
                                 element: d3.Selection<SVGElement, TesslaStream, null, undefined>,
                                 d: TesslaStream, y: (e: TesslaEvent) => number) {
  const data = d.data;

  function updateArrow(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    elem.attr("x", (dd) => main.xScale(dd.time)).attr("y", y);
  }

  function updateCircle(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    elem.attr("cx", (dd) => main.xScale(dd.time)).attr("cy", y);
  }

  if (d.editable) {
    const arrows = element.selectAll("use.arrow").data(data).call(updateArrow);
    arrows.enter().append("use").attr("class", "arrow")
      .attr("y", y).attr("href", `#${main.prefix}arrow`).attr("opacity", 0).call(updateArrow);
  } else {
    element.selectAll("use.arrow").remove();
  }

  const circles = element.selectAll("circle.dragger").data(data).call(updateCircle);
  circles.exit().remove();
  const newCircles = circles.enter()
    .append("circle").attr("class", "dragger")
    .attr("r", main.options.draggerRadius).attr("cy", y)
    .attr("opacity", 0)
    .call(updateCircle).call(main.tooltip);

  function createDrag() {
    let dragIndex = -1;

    function dragStart(_: TesslaEvent, i: number) {
      dragIndex = i;
    }

    function dragEnd() {
      if (dragIndex > -1) {
        dragIndex = -1;
        if (main.options.onDragEnd !== undefined) {
          main.options.onDragEnd(d, dragIndex);
        }
      }
    }

    function dragged() {
      if (dragIndex > -1) {
        const currentData = data[dragIndex];
        currentData.time = limitAndRound(main.xScale.invert(d3.event.x), main.xScale.domain() as [number, number],
          main.options.dragPrecision);
        dragIndex = repositionEvent(data, currentData, dragIndex);
        if (main.options.onDrag !== undefined) {
          main.options.onDrag(d, dragIndex);
        }
        main.display();
        updateTooltip(main.tooltipDiv, currentData, d3.event.sourceEvent.pageX, d3.event.sourceEvent.pageY);
      }
    }

    const drag = d3.drag<SVGElement, TesslaEvent>()
      .on("start", dragStart)
      .on("end", dragEnd)
      .on("drag", dragged);

    newCircles.attr("cursor", "ew-resize").call(drag);
  }

  if (d.editable) {
    createDrag();
  }
}
