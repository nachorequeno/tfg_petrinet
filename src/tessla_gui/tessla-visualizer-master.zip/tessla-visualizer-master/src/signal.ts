import * as d3 from "d3";
import { Main, TesslaEvent, TesslaStream } from "./interfaces";

import { circlesAndArrows, crisp } from "./tools";

export function displaySignal(d: TesslaStream, i: number, offset: number,
                              element: d3.Selection<SVGElement, TesslaStream, null, undefined>, main: Main) {
  const data = d.data;
  const h = main.options.signalHeight;
  const y = offset + h;

  function path(ii: number) {
    const dx = main.options.signalHeight / 2;

    function firstSignal(xx: number, yy: number, w: number) {
      const wd = w - dx;
      if (wd < 0) {
        return `M ${xx} ${yy} v ${-dx} l ${w} ${dx} l ${-w} ${dx} z`;
      }
      return `M ${xx} ${yy} v ${-dx} h ${wd} l ${dx} ${dx} l ${-dx} ${dx} h ${-wd} z`;
    }

    function lastSignal(xx: number, yy: number, w: number) {
      const wd = w - dx;
      if (wd < 0) {
        return `M ${xx} ${yy} l ${w} ${-dx} v ${2 * dx} z`;
      }
      return `M ${xx} ${yy} l ${dx} ${-dx} h ${wd} v ${2 * dx} h ${-wd} z`;
    }

    function signal(xx: number, yy: number, w: number) {
      const wd = w - main.options.signalHeight;
      if (wd < 0) {
        return `M ${xx} ${yy} l ${w / 2} ${-dx} l ${w / 2} ${dx} l ${-w / 2} ${dx} z`;
      }
      return `M ${xx} ${yy} l ${dx} ${-dx} h ${wd} l ${dx} ${dx} l ${-dx} ${dx} h ${-wd} z`;
    }

    const x = main.xScale(data[ii].time);
    let width;
    if (ii + 1 < data.length) {
      width = main.xScale(data[ii + 1].time) - x;
    } else {
      width = main.xScale.range()[1] - x;
    }
    if (data[ii].time <= 0) {
      return firstSignal(x, y, width);
    } else if (ii === data.length - 1) {
      return lastSignal(x, y, width);
    } else {
      return signal(x, y, width);
    }
  }

  function updateXAxis(elem: d3.Selection<d3.BaseType, null, SVGElement, TesslaStream>) {
    if (data.length > 0) {
      if (data[0].time > 0) {
        const end = main.xScale(data[0].time) + 1;
        elem.attr("d", `M ${main.xScale(0)} ${y + h / 4} l 0 ${-h / 2} m 0 ${h / 4} L ${end} ${y}`);
      } else {
        elem.attr("d", "");
      }
    } else {
      elem.attr("d", `M ${main.xScale(0)} ${y + h / 4} l 0 ${-h / 2} m 0 ${h / 4} L ${main.width} ${y}`);
    }
  }

  const xaxis = element.selectAll("path.xaxis").data([null]).call(crisp).call(updateXAxis);
  xaxis.enter().append("path").attr("class", "xaxis")
    .attr("stroke", "black")
    .call(updateXAxis);

  let label = main.container.selectAll(`text#${main.prefix}label-${i}`).data([null]);
  label = label.enter().append("text").attr("id", `${main.prefix}label-${i}`)
    .attr("text-anchor", "end")
    .attr("font-size", main.options.fontSize)
    .attr("dominant-baseline", "central").merge(label);
  label.attr("x", main.labelWidth - main.options.labelDistance)
    .attr("y", y).text(d.name);

  function updateClips(elem: d3.Selection<d3.BaseType, TesslaEvent, d3.BaseType, null>) {
    elem.each(function(dd, ii) {
      const e = d3.select(this);
      let p = e.selectAll("path").data([null]);
      p = p.enter().append("path").merge(p);
      p.attr("d", path(ii));
    });
  }

  let defs = element.selectAll("defs").data([null]);
  defs = defs.enter().append("defs").merge(defs);
  const clips = defs.selectAll("clipPath").data(data).call(updateClips);
  clips.enter().append("clipPath")
    .attr("id", (dd, ii) => `${main.prefix}stream-${i}-signal-${ii}-clip`).call(updateClips);

  function updatePath(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    elem.attr("d", (dd, ii) => path(ii))
      .attr("fill", main.fillColor)
      .attr("stroke", main.strokeColor);
  }

  const paths = element.selectAll("path.signal").data(data).call(updatePath);
  paths.enter().append("path").attr("class", "signal")
    .attr("stroke-width", 2).call(updatePath);
  paths.exit().remove();

  function updateTexts(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    function w(ii: number) {
      let end: number;
      if (ii < data.length - 1) {
        end = main.xScale(data[ii + 1].time);
      } else {
        end = main.width;
      }
      return end - main.xScale(data[ii].time);
    }
    function x(ii: number) {
      return main.xScale(data[ii].time) + w(ii) / 2;
    }
    elem.attr("x", (dd, ii) => x(ii))
      .text(main.textLabel)
      .attr("fill", main.textColor);
  }

  const texts = element.selectAll("text.signal").data(data).call(updateTexts);
  texts.enter().append("text").attr("class", "signal")
    .attr("clip-path", (dd, ii) => `url(#${main.prefix}stream-${i}-signal-${ii}-clip)`)
    .attr("text-anchor", "middle")
    .attr("font-size", main.options.fontSize)
    .attr("y", y).attr("dominant-baseline", "central")
    .call(updateTexts);
  texts.exit().remove();

  circlesAndArrows(main, element, d, () => y);
}
