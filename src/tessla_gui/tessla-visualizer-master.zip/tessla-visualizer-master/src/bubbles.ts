import * as d3 from "d3";
import { Main, TesslaEvent, TesslaStream } from "./interfaces";

import { circlesAndArrows, crisp } from "./tools";

export function displayBubbles(d: TesslaStream, i: number, offset: number,
                               element: d3.Selection<SVGElement, TesslaStream, null, undefined>, main: Main) {
  const data = d.data;
  const h = main.options.bubbleHeight;
  const y = offset + h;

  let xaxis = element.selectAll("path.xaxis").data([null]);
  xaxis = xaxis.enter().append("path").attr("class", "xaxis").call(crisp)
    .attr("stroke", "black").merge(xaxis);
  xaxis.attr("d", `M ${main.xScale(0)} ${y + h / 4} l 0 ${-h / 2} m 0 ${h / 4} L ${main.width} ${y}`);

  let label = main.container.selectAll(`text#${main.prefix}label-${i}`).data([null]);
  label = label.enter().append("text").attr("id", `${main.prefix}label-${i}`)
    .attr("text-anchor", "end")
    .attr("font-size", main.options.fontSize)
    .attr("dominant-baseline", "central").merge(label);
  label.attr("x", main.labelWidth - main.options.labelDistance)
    .attr("y", y).text(d.name);

  function updateClips(elem: d3.Selection<d3.BaseType, TesslaEvent, d3.BaseType, null>) {
    elem.each(function(dd: TesslaEvent, ii: number) {
      const e = d3.select(this);
      let p = e.selectAll("circle").data([null]);
      p = p.enter().append("circle").merge(p);
      p.attr("cx", main.xScale(dd.time)).attr("r", main.options.bubbleHeight / 1.5).attr("cy", y);
    });
  }

  let defs = element.selectAll("defs").data([null]);
  defs = defs.enter().append("defs").merge(defs);
  const clips = defs.selectAll("clipPath").data(data).call(updateClips);
  clips.enter().append("clipPath")
    .attr("id", (dd, ii) => `${main.prefix}stream-${i}-event-${ii}-clip`)
    .call(updateClips);
  clips.exit().remove();

  function updateBubble(elem: d3.Selection<d3.BaseType, TesslaEvent, any, {}>) {
    elem.each(function(dd) {
      const group = d3.select(this);
      group.select("text")
        .attr("x", main.xScale(dd.time))
        .text(main.textLabel(dd))
        .attr("fill", main.textColor(dd));
      group.select("circle").attr("cx", main.xScale(dd.time))
      .attr("fill", main.fillColor(dd)).attr("stroke", main.strokeColor(dd));
    });
  }

  const bubbles = element.selectAll("g.bubble").data(data).call(updateBubble);
  const newBubbleGroups = bubbles.enter().append("g").attr("class", "bubble");
  newBubbleGroups.append("circle")
    .attr("r", main.options.bubbleHeight / 1.5).attr("cy", y)
    .attr("stroke-width", 2);
  newBubbleGroups.append("text").attr("text-anchor", "middle")
    .attr("y", y).attr("dominant-baseline", "central")
    .attr("font-size", main.options.fontSize)
    .attr("clip-path", (dd, ii) => `url(#${main.prefix}stream-${i}-event-${ii}-clip)`);
  newBubbleGroups.call(updateBubble);
  bubbles.exit().remove();

  circlesAndArrows(main, element, d, () => y);
}
