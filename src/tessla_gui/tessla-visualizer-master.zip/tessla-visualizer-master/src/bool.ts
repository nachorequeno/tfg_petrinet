import * as d3 from "d3";
import { Main, TesslaStream } from "./interfaces";

import { circlesAndArrows, crisp } from "./tools";

export function displayBool(d: TesslaStream, i: number, offset: number,
                            element: d3.Selection<SVGElement, TesslaStream, null, undefined>, main: Main) {
  const data = d.data;
  const h = main.options.boolHeight;
  const y = offset + h;

  let xaxis = element.selectAll("path.xaxis").data([null]);
  xaxis = xaxis.enter().append("path").attr("class", "xaxis").call(crisp)
    .attr("stroke", "black").attr("fill", "none").merge(xaxis);
  xaxis.attr("d", `M ${main.xScale(0)} ${y} L ${main.width} ${y}`);

  let label = main.container.selectAll(`text#${main.prefix}label-${i}`).data([null]);
  label = label.enter().append("text").attr("id", `${main.prefix}label-${i}`)
    .attr("font-size", main.options.fontSize)
    .attr("text-anchor", "end")
    .merge(label);
  label.attr("x", main.labelWidth - main.options.labelDistance)
    .attr("y", y)
    .text(d.name);

  let plotFill = element.selectAll("path.plot-fill").data([null]);
  plotFill = plotFill.enter().append("path").attr("stroke-width", 2).attr("class", "plot-fill").merge(plotFill);
  const firstTime = data.length > 0 ? data[0].time : 0;
  plotFill.attr("fill", main.strokeColor).attr("stroke", main.strokeColor)
    .attr("d", `M ${main.xScale(firstTime)} ${y}` +
      data.map((dd) => ` H ${main.xScale(dd.time)} V ${dd.value ? offset : y}`).join("") +
        ` H ${main.width} V ${y}`);

  circlesAndArrows(main, element, d, (dd) => dd.value ? offset : y);
}
