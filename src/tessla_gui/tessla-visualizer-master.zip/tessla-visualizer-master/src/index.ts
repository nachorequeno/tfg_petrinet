import { TesslaEvent, TesslaStream, Visualizer, VisualizerOptions } from "./interfaces";

// TODO axis should never have negative values
// TODO resize() should update tick resolution of the axis, too
// TODO last visible event in signal should be handled as last event, even if there are other
//      invisible events after this one, i.e. the label should be centered between the event
//      and the right end of the diagram in that case.

// TODO signal.ts seems to have rounding issues if the length of an element becomes very large.
//      This bug occurs if the not drawn progress event at the end of the example diagrams
//      has a timestamp greater than 1000000.
// TODO Add additional space before first event even if first event is at timestamp 0. Compute the extra
//      space which is added to the time domain such that it is a fixed (configurable) amount of pixels.
//      Handle initial x-axis mark more consistent: For plot this is always at the left and for events
//      it is only at time 0.

import * as d3 from "d3";

import { displayBool } from "./bool";
import { displayBubbles } from "./bubbles";
import { displayDots } from "./dots";
import { displayEvents } from "./events";
import { displayGraph } from "./graph";
import { displayPlot } from "./plot";
import { displaySignal } from "./signal";

import { ZoomTransform } from "d3";
import { addDefault, crisp, updateTooltip } from "./tools";

let globalId = 0;

export function visualizer(containerSelectorOrElement: string|Element, options: VisualizerOptions): Visualizer {
  const defaultOptions = {
    axis: true,
    axisOffset: 30,
    boolHeight: 21,
    bubbleHeight: 21,
    color: "#0000ff",
    dragPrecision: 10,
    draggerRadius: 10,
    eventHeight: 14,
    fontSize: 16,
    labelDistance: 10,
    maxZoom: 40,
    plotHeight: 100,
    signalHeight: 20,
    streams: [],
  };
  addDefault(options, defaultOptions);

  // Height of the first num streams
  function heightOf(num: number) {
    const heights = {
      "bool": options.boolHeight + 10,
      "bubbles": options.bubbleHeight * 2,
      "dots": options.plotHeight + 10,
      "events": options.eventHeight * 3,
      "graph": options.plotHeight + 10,
      "plot": options.plotHeight + 10,
      "signal": options.signalHeight * 2,
      "slim graph": options.plotHeight + 10,
      "slim plot": options.plotHeight + 10,
      "unit events": options.eventHeight * 2,
    };
    const sum = d3.sum(options.streams.slice(0, num).map((stream) => {
      const h = heights[stream.style];
      if (!h) {
        throw new Error(`Unknown stream style "${stream.style}"`);
      }
      return h;
    }));
    if (options.axis) {
      return sum + options.axisOffset;
    } else {
      return sum;
    }
  }

  const container = (typeof containerSelectorOrElement === "string") ?
    d3.select(containerSelectorOrElement) as d3.Selection<Element, {}, any, undefined> :
    d3.select(containerSelectorOrElement);
  globalId += 1;
  const prefix = `visualizer-${globalId}-`;
  let width = (container.node() as HTMLElement).getBoundingClientRect().width;
  const height = heightOf(options.streams.length);
  container.style("height", height + "px");

  // compute default labelWidth
  function computeLabelWidth() {
    if (options.labelWidth) {
      return options.labelWidth;
    } else {
      const label = container.append("text");
      label.attr("font-size", options.fontSize);
      const widths = options.streams.map((s) => {
        label.text(s.name);
        return (label.node() as SVGGraphicsElement).getBBox().width;
      });
      label.remove();
      const max = Math.max(...widths);
      return max + options.labelDistance;
    }
  }
  const labelWidth = computeLabelWidth();

  const defs = container.append("defs");
  const clip = defs.append("clipPath").attr("id", prefix + "clip");
  clip.append("path").
    attr("d", `M ${labelWidth - options.labelDistance} 0 H ${width} V ${height}` +
    ` H ${labelWidth - options.labelDistance} z`);

  const marker = defs.append("marker").attr("id", prefix + "marker");
  marker.append("path").attr("d", "M1,1 C1,2 2,4 4,4 C 2,4 1,6 1,7")
    .attr("fill", "none").attr("stroke", "black")
    .attr("stroke-linejoin", "round")
    .attr("stroke-linecap", "round");
  marker.attr("markerWidth", 5).attr("markerHeight", 8).
    attr("refX", 4).attr("refY", 4).
    attr("orient", "auto").attr("markerUnits", "strokeWidth");

  const streamContainer = container.append("g").attr("clip-path", `url(#${prefix}clip)`);

  function computeTimeDomain() {
    if (options.timeDomain) {
      return options.timeDomain;
    }
    const extentOrUndefined = d3.extent(options.streams.map((stream) => stream.data)
    .reduce(((a, b) => a.concat(b))), (d: TesslaEvent) => d.time);
    const extent: [number, number] = [extentOrUndefined[0] || 0, extentOrUndefined[1] || 1];
    return [
      Math.max(0, extent[0] - (extent[1] - extent[0]) * .05),
      extent[1] + (extent[1] - extent[0]) * .05,
    ] as [number, number];
  }
  const timeDomain = computeTimeDomain();

  const xScaleBase = d3.scaleLinear().domain(timeDomain).range([labelWidth, width]);
  let xScale = xScaleBase.copy();

  const axisContainer = container.append("g").attr("transform", "translate(0,25)").call(crisp);
  const axis = d3.axisTop(xScale)
    .ticks(Math.floor(width / (Math.log(timeDomain[1] - timeDomain[0]) / Math.log(10) + 1) / 12));
  if (options.axis) {
    axisContainer.call(axis);
  }

  let tooltipDiv = d3.select("body").select("div#visualizerToolTip");
  if (tooltipDiv.empty()) {
    tooltipDiv = d3.select("body").append("div")
      .attr("id", "visualizerToolTip")
      .attr("style", "opacity: 0; position: absolute; top: 0; left: 0;" +
        "background-color: #ffc; padding: 3px; border: solid 1px black; z-index: 2222;");
  }
  function tooltip(elements: d3.Selection<d3.BaseType, TesslaEvent, any, {}>) {
    elements.on("mouseover", () =>
      tooltipDiv
        .transition().duration(200)
        .style("opacity", 1))
    .on("mousemove", (d) => updateTooltip(tooltipDiv, d, d3.event.pageX, d3.event.pageY))
    .on("mouseout", () =>
      tooltipDiv
        .transition().duration(500)
        .style("opacity", 0));
  }

  const zoom = d3.zoom()
    .scaleExtent([1, options.maxZoom])
    .extent([[labelWidth, 0], [width, 0]])
    .translateExtent([[labelWidth, 0], [width, 0]])
    .on("zoom", () => zoomed(d3.event.transform));
  container.call(zoom);

  function zoomed(zoomTransform: ZoomTransform) {
    xScale = zoomTransform.rescaleX(xScaleBase);
    axis.scale(xScale);
    if (options.axis) {
      axisContainer.call(axis);
    }
    display();
  }

  function buildArrow() {
    const r = options.draggerRadius;
    const arrow = defs.append("g").attr("id", prefix + "arrow").attr("fill", "red")
      .attr("stroke", "red").attr("stroke-width", 2).attr("stroke-linejoin", "round");
    arrow.append("circle").attr("r", options.draggerRadius);
    arrow.append("path").attr("d", `M 0 ${r / 3} h ${2 * r} v ${2 / 3 * r} l ${r} ${-r} l ${-r} ${-r} ` +
      `v ${2 / 3 * r} h ${-4 * r} v ${-2 / 3 * r} l ${-r} ${r} l ${r} ${r} v ${-2 / 3 * r} z`);
  }
  buildArrow();

  function brushEnd() {
    const s = d3.event.selection;
    if (s) {
      // reset brush
      if (brushElement !== undefined) {
        brush.move(brushElement, null);
      }
      // zoom to selection
      const targetDomain = [s[0], s[1]].map(xScale.invert);
      const baseDomain = xScaleBase.domain();
      const targetWidth = targetDomain[1] - targetDomain[0];
      const baseWidth = baseDomain[1] - baseDomain[0];
      let scale = baseWidth / targetWidth;
      if (scale > options.maxZoom) {
        scale = options.maxZoom;
        // center targetDomain in actual domain based on new scale
        const correctedTargetWidth = baseWidth / scale;
        targetDomain[0] = Math.max(0, targetDomain[0] - (correctedTargetWidth - targetWidth) / 2);
      }
      // respect labelWidth as left zoom extent
      const xTranslate = labelWidth / scale - xScaleBase(targetDomain[0]);
      zoom.transform(container, d3.zoomIdentity
        .scale(scale)
        .translate(xTranslate, 0));
    }
  }
  const brush = d3.brushX().extent([[labelWidth, 0], [width, height]]).on("end", brushEnd);
  let brushElement: d3.Selection<SVGGElement, {}, any, any> | undefined;

  function enableBrush() {
    if (!brushElement) {
      brushElement = container.append("g").attr("class", "brush") as d3.Selection<SVGGElement, {}, any, any>;
      brush(brushElement);
    }
  }
  function disableBrush() {
    if (brushElement) {
      brushElement.remove();
      brushElement = undefined;
    }
  }

  function showArrows() {
    container.selectAll("use.arrow").transition().duration(200)
      .attr("opacity", 1).transition().duration(2000).attr("opacity", 0);
  }

  function display() {
    const streams = streamContainer.selectAll("g.stream").data(options.streams).each(displayStream);
    streams.enter().append("g").attr("class", "stream").each(displayStream);
    streams.exit().remove();
  }
  display();

  function displayStream(d: TesslaStream, i: number) {
    const element = d3.select(this) as d3.Selection<SVGElement, TesslaStream, null, undefined>;
    const offset = heightOf(i);

    const displayFunction = {
      "bool": displayBool,
      "bubbles": displayBubbles,
      "dots": displayDots,
      "events": displayEvents,
      "graph": displayGraph,
      "plot": displayPlot,
      "signal": displaySignal,
      "slim graph": displayGraph,
      "slim plot": displayPlot,
      "unit events": displayEvents,
    }[d.style];
    if (!displayFunction) {
      throw new Error(`Unknown stream style "${d.style}"`);
    }

    function textLabel(dd: TesslaEvent) {
      if (typeof d.text === "function") {
        return d.text(dd);
      } else if (typeof options.text === "function") {
        return options.text(dd);
      } else if (dd.value !== undefined && dd.value !== null) {
        return dd.value.toString();
      } else {
        return "";
      }
    }

    function strokeColor(dd: TesslaEvent | null): string {
      if (dd && dd.color) {
        return dd.color;
      } else if (typeof d.color === "function") {
        return d.color(dd);
      } else if (typeof d.color === "string") {
        return d.color;
      } else if (typeof options.color === "function") {
        return options.color(dd);
      } else {
        return options.color;
      }
    }

    function textColor(dd: TesslaEvent | null) {
      const c = d3.hsl(strokeColor(dd));
      c.l = 0.25;
      return c.toString();
    }

    function fillColor(dd: TesslaEvent | null) {
      const c = d3.hsl(strokeColor(dd));
      c.l = 0.9;
      return c.toString();
    }

    displayFunction(d, i, offset, element,
      {container, display, fillColor, labelWidth, options, prefix, strokeColor, textColor, textLabel,
        tooltip, tooltipDiv, width, xScale});
  }

  function resize() {
    width = (container.node() as HTMLElement).getBoundingClientRect().width;
    clip.select("path").attr("d", `M ${labelWidth - 1} 0 H ${width} V ${height} H ${labelWidth - 1} z`);
    xScaleBase.range([labelWidth, width]);
    zoom.extent([[labelWidth, 0], [width, 0]])
        .translateExtent([[labelWidth, 0], [width, 0]]);
    brush.extent([[labelWidth, 0], [width, height]]);
    axis.ticks(Math.floor(width / (Math.log(timeDomain[1] - timeDomain[0]) / Math.log(10) + 1) / 12));
    // Simulate zoom event to re-apply xScaleBase and redraw everything
    zoomed(d3.zoomTransform(container.node() as HTMLElement));
  }

  return {
    disableBrush,
    display,
    enableBrush,
    options,
    resize,
    showArrows,
  };
}
