export interface TesslaEvent {
  color: string | undefined;
  time: number;
  value: number | undefined;
}

export interface TesslaStream {
  color: string | ((e: TesslaEvent | null) => string) | null;
  data: TesslaEvent[];
  editable: boolean;
  name: string;
  style: "signal" | "dots" | "graph" | "slim graph" | "plot" | "slim plot" | "events" | "unit events" | "bubbles";
  text: ((e: TesslaEvent) => string) | null;
}

export interface VisualizerOptions {
  axis: boolean;
  axisOffset: number;
  bubbleHeight: number;
  boolHeight: number;
  color: string | ((e: TesslaEvent | null) => string);
  draggerRadius: number;
  dragPrecision: number;
  eventHeight: number;
  fontSize: string;
  labelWidth: number | undefined;
  labelDistance: number;
  maxZoom: number;
  onDrag: (stream: TesslaStream, dragIndex: number) => void | undefined;
  onDragEnd: (stream: TesslaStream, dragIndex: number) => void | undefined;
  plotHeight: number;
  signalHeight: number;
  streams: TesslaStream[];
  text: ((e: TesslaEvent) => string);
  timeDomain: [number, number] | undefined;
}

export interface Main {
  container: d3.Selection<Element, {}, any, undefined>;
  display: () => void;
  fillColor: (d: TesslaEvent | null) => string;
  labelWidth: number;
  options: VisualizerOptions;
  prefix: string;
  strokeColor: (d: TesslaEvent | null) => string;
  textColor: (d: TesslaEvent | null) => string;
  textLabel: (d: TesslaEvent) => string;
  tooltip: (elements: d3.Selection<d3.BaseType, TesslaEvent, any, {}>) => void;
  tooltipDiv: d3.Selection<d3.BaseType, {}, HTMLElement, any>;
  width: number;
  xScale: d3.ScaleLinear<number, number>;
}

export interface Visualizer {
  disableBrush: () => void;
  display: () => void;
  enableBrush: () => void;
  options: VisualizerOptions;
  resize: () => void;
  showArrows: () => void;
}
