import * as d3 from "d3";
import { Main, TesslaEvent, TesslaStream } from "./interfaces";

import { circlesAndArrows, crisp } from "./tools";

export function displayPlot(d: TesslaStream, i: number, offset: number,
                            element: d3.Selection<SVGElement, TesslaStream, null, undefined>, main: Main) {
  const data = d.data;
  const extent = d3.extent(data.map((dd) => dd.value || 0));
  const minValue = Math.min(extent[0] || 0, 0);
  const maxValue = Math.max(extent[1] || 1, 0);
  const yScale = d3.scaleLinear().domain([minValue, maxValue])
    .range([offset + main.options.plotHeight + 5, offset + 5]);

  let xaxis = element.selectAll("path.xaxis").data([null]);
  xaxis = xaxis.enter().append("path").attr("class", "xaxis").call(crisp)
    .attr("stroke", "black").attr("fill", "none").merge(xaxis);
  xaxis.attr("d", `M ${main.xScale(0)} ${yScale(0)} L ${main.width} ${yScale(0)}`);

  let yaxis = element.selectAll("path.yaxis").data([null]);
  yaxis = yaxis.enter().append("path").attr("class", "yaxis").call(crisp)
    .attr("stroke", "black").attr("fill", "none").merge(yaxis);
  yaxis.attr("d", `M ${main.xScale(0)} ${yScale(minValue)} L ${main.xScale(0)} ${yScale(maxValue)}`);
  yaxis.attr("marker-end", `url(#${main.prefix}marker)`);

  let label = main.container.selectAll(`text#${main.prefix}label-${i}`).data([null]);
  label = label.enter().append("text").attr("id", `${main.prefix}label-${i}`)
    .attr("font-size", main.options.fontSize)
    .attr("text-anchor", "end")
    .merge(label);
  label.attr("x", main.labelWidth - main.options.labelDistance)
    .attr("y", yScale(0))
    .text(d.name);

  let plotFill = element.selectAll("path.plot-fill").data([null]);
  plotFill = plotFill.enter().append("path").attr("class", "plot-fill").merge(plotFill);
  plotFill.attr("fill", main.fillColor)
    .attr("d", `M ${main.xScale(0)} ${yScale(0)}` +
      data.map((dd) => ` H ${main.xScale(dd.time)} V ${yScale(dd.value || 0)}`).join("") +
        ` H ${main.width} V ${yScale(0)}`);

  let plot = element.selectAll("path.plot").data([null]);
  plot = plot.enter().append("path").attr("class", "plot")
    .attr("stroke-width", 2).attr("fill", "none").merge(plot);
  const firstTime = data.length > 0 ? data[0].time : 0;
  plot.attr("stroke", main.strokeColor)
    .attr("d", `M ${main.xScale(firstTime)} ${yScale(0)}` +
      data.map((dd) => ` H ${main.xScale(dd.time)} V ${yScale(dd.value || 0)}`).join("")
        + ` H ${main.width}`);

  function updateCircle(elem: d3.Selection<d3.BaseType, TesslaEvent, SVGElement, TesslaStream>) {
    elem.attr("cx", (dd) => main.xScale(dd.time))
      .attr("cy", (dd) => yScale(dd.value || 0))
      .attr("fill", main.strokeColor);
  }

  if (d.style !== "slim plot") {
    const eventCircles = element.selectAll("circle.event").data(data).call(updateCircle);
    eventCircles.enter()
      .append("circle").attr("class", "event").attr("r", 5).call(updateCircle);
    eventCircles.exit().remove();
  }

  circlesAndArrows(main, element, d, (dd) => yScale(dd.value || 0));
}
