TeSSLa Visualizations
=====================

Visualizations
--------------

* Signals (with label text or with colors/patterns)
* Events (with label text or with colors/patterns or without values)
* Plots
  * discrete dots
  * piecewise-constant plots

GUI
---

* Zoom & Pan
* Timestamps
* Cursor (current position & next/previous per stream)

d3.js
-----

* d3-scale: linear scale, `.nice()`, `.ticks()`
* d3-axis
* d3-brush, d3-zoom
* d3-drag

API
---

```json
event: {time, value, color/style/css}
stream: {events, name, style}
```

* Set & manipulate multiple streams
* Receive manipulation callbacks of editable streams
  * add event
  * delete event
  * move event
  * edit value
