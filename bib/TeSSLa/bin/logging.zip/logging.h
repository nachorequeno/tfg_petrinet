#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

uint8_t *trace_create_events(uintptr_t capacity);

void trace_push_bool(uint8_t *events, const char *name, bool value);

void trace_push_float(uint8_t *events, const char *name, double value);

void trace_push_int(uint8_t *events, const char *name, int64_t value);

void trace_push_thread_id(uint8_t *events, const char *name);

void trace_push_unit(uint8_t *events, const char *name);

void trace_write(uint8_t *events);
